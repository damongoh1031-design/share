# 自适应定级测评题库与出题规则

> 首诊定级用。目标：8–12 题、约 5 分钟收敛到 CEFR 等级（A1–C1）。题库是样例 + 平行出题规则——实际测评时可按同难度特征现场生成新题，避免老用户遇到重复题。

## 一、流程规则

1. **自述三问**（对话式，穿插进行，不要连环审问）：
   - 学英语多久了？最近在学什么/用什么材料？
   - 自己觉得是什么水平？（完全零基础 / 能简单说几句 / 能日常交流 / 比较流利）
   - 考过什么试、多少分？（如有）
2. **起点档估计**（由自述映射）：

| 自述线索 | 起点档 |
|---|---|
| 零基础 / 学过不到 1 年 / 只记得字母和零星单词 | A1 |
| 学过 1–3 年 / 初中水平 / 能说简单句子 | A2 |
| 高中水平 / 四级已过或 400+ / 能应付日常话题 | B1 |
| 六级已过 / 考研英语 / 雅思 5.5–6.5 / 能看美剧跟读 | B2 |
| 雅思 7+ / 专八 / 能流畅讨论抽象话题 | C1 |

3. **自适应升降档**：从起点档出题。该档 4 题中答对 ≥3 → 升一档继续出 4 题；答对 ≤2 → 停止，定级为当前档。**连错 2 题立即停止**（无需出满 4 题）。C1 档答对 ≥3 → 定 C1（不出 C2，超出服务定位时如实说明）。
4. **题目呈现**：一次一题，答完再出下一题。A1–A2 档用中文引导（题目本身是英语）；B1 起用英文出题。
5. **定级输出**：等级 + can-do 对照（现在能做什么/下一级能做什么）+ 置信度说明（±1 子级，前两周留校正空间）。

## 二、各档样题

### A1 档（特征：高频词辨析、基础时态、单句理解）

1. 【词汇】「一本书」是哪个词？ book / foot / door / food → **book**
2. 【语法】She ___ to school every day. go / goes / going / gone → **goes**
3. 【语法】I ___ a student. is / are / am / be → **am**
4. 【理解】短文：Tom has a red bike and a black cat. 问：What does Tom have? → **a red bike and a black cat**

平行出题特征：最高频 500 词内的名词/动词辨析；一般现在时第三人称单数、be 动词、单句直接细节理解。

### A2 档（特征：常用搭配、过去时/完成时、双句推断）

1. 【词汇】I usually ___ up at 7 o'clock. wake / weak / walk / wall → **wake**（辨析形近词）
2. 【语法】I ___ to the park yesterday. go / went / goes / going → **went**
3. 【语法】She has lived here ___ 2010. for / since / at / from → **since**
4. 【理解】短文：Maria wants to buy a dress, but the shop is closed on Sundays. 今天是周日。Can Maria buy the dress today? → **不能，商店关门**

平行出题特征：形近词辨析、一般过去时不规则动词、since/for、需要一步推断的两句短文。

### B1 档（特征：中级词汇、条件句/关系从句、四句短文主旨+推断）

1. 【词汇】The meeting was ___ — nobody had prepared anything. ruined… 选词：bored / pointless / delighted / brief → **pointless**
2. 【语法】If I ___ more time, I would travel more. have / had / will have / having → **had**
3. 【语法】He's the man ___ helped me yesterday. which / who / whose / whom → **who**
4. 【理解】短文（4 句左右）：Jamie 想换工作因为通勤太久，但又担心新工作压力。问：What is Jamie's dilemma? → **想换工作但有顾虑**

平行出题特征：描述性形容词辨析、第二条件句、限制性关系从句、人物动机/两难推断。

### B2 档（特征：学术/书面词汇、倒装与虚拟语气、议论短文作者态度）

1. 【词汇】The results were ___ with earlier findings. consistent / constant / persistent / insistent → **consistent**
2. 【语法】Not until the storm passed ___ able to leave. we were / were we / we had / did we → **were we**（否定倒装）
3. 【语法】I'd rather you ___ tell anyone about this. don't / didn't / won't / wouldn't → **didn't**（would rather + 虚拟）
4. 【理解】短文（议论性 4–5 句）：某研究者列数据后用 "That said, ..." 转折。问：作者对原始观点的真实态度 → **有保留的认同/部分质疑**

平行出题特征：近义书面词辨析、否定倒装、would rather/wish 虚拟、识别转折词后的作者真实立场。

### C1 档（特征：低频精准词、复杂语法结构、学术短文推断与语用）

1. 【词汇】The report's conclusions are ___ at best — the data simply don't support them. tentative / tenable / tenacious / temperate → **tentative**
2. 【语法】Rarely ___ such a decisive victory in a first debate. has one seen / one has seen / one saw / seen has one → **has one seen**
3. 【语法】The minister is believed ___ overseas at the time of the incident. to be / to have been / being / been → **to have been**（完成式不定式）
4. 【理解】短文（学术性 5 句）：作者引用反方观点后用 "While this may be so, ..." 问：作者建构论证的方式 → **先让步再反驳（concede-then-rebut）**

平行出题特征：精准低频词、倒装+完成式不定式+被动推理结构、识别让步反驳等论证结构。

## 三、can-do 对照（定级输出时引用）

- **A1**：能进行最基本的个人信息交换；能写简单留言。→ A2：能应付日常简单对话、描述身边事物。
- **A2**：能应付旅行中大多数简单情境。→ B1：能应对旅行中大部分情境、就熟悉话题写连贯短文。
- **B1**：能就熟悉话题连贯表达观点。→ B2：能就抽象话题自然交流、理解复杂文章主旨。
- **B2**：能与母语者就广泛话题自然互动。→ C1：能流利参与抽象/学术话题讨论、快读长难材料。
- **C1**：能流利自如地表达、有效进行语义重构。→ 服务定位上限，向上建议专项资源（如 C2 备考材料）。

## 四、特殊情形

- 用户带旧档案回访：**跳过测评**，直接用档案等级校准；练习表现与档案明显不符（连续答对超档题/大量低档错误）时提出重测建议，由用户决定。
- 用户拒绝测评：按自述定档并标注「低置信度」，方案前两周明确留校正条款。
- 用户中途想跳过：允许直接告诉搭子目标水平，定级结果标「自报未验证」。
