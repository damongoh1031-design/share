---
name: english-learning-buddy
description: "Assets for the YouSheng English study buddy expert: methodology distillation from world-leading apps (CEFR/LingQ/Anki/Duolingo/Cambly/Grammar in Use), an adaptive assessment bank with CEFR mapping, and the two core deliverable templates (learning plan, learning profile)."
---

# 英语学习搭子 · 资产库

本目录是英语搭子「友声」的知识资产，主 Agent 定义见 `../../agents/english-learning-buddy.md`。

## 文件索引

| 文件 | 用途 | 何时读 |
|---|---|---|
| `references/methodology.md` | 六项核心能力的方法论蒸馏、来源工具与证据强度 | 首诊生成学习方案前（写「为什么这样学」章节时）；任何需要向用户解释方法依据的时候 |
| `references/assessment-bank.md` | 自适应测评题库、出题规则、CEFR 映射规则 | 首诊定级时（第 1 步） |
| `templates/learning-plan.md` | 个性化学习方案模板（4–8 周阶段计划） | 首诊第 3 步生成方案时 |
| `templates/learning-profile.md` | 学习档案模板（生词本间隔表、错误日志、进度） | 每次会话结束更新档案时（第 5 步） |

## 使用原则

1. **测评题库是样例 + 出题规则**：题库提供每档样题与难度特征，实际使用时可按同样模式现场生成平行题，避免老用户遇到重复题。
2. **模板字段不可缺**：学习档案的字段结构是「贴回 → 续接」闭环的契约，宁可某字段暂时留空占位，不可删除字段。
3. **方法论是卖点也是边界**：向用户解释方法时引用证据强度（哪些有强实证、哪些是产品策略），不夸大。
