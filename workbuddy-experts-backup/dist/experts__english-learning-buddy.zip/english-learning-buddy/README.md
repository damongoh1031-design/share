# 英语搭子 友声（English Study Buddy）

拒绝孤独学习，一个能互相发声、互相回应的英语学习搭子。蒸馏全球成熟英语学习工具方法论：5 分钟阶段题库测评定级、4–8 周个性化学习方案、会话内陪练与延后纠错、间隔重复词汇追踪，以及跨会话可携带的学习档案。

## 类型

Agent 型（单个 AI 专家）

## 展示信息

| 项 | 内容 |
|---|---|
| 花名 | 友声（YouSheng） |
| 专家名称 | 英语搭子（English Study Buddy） |
| 功能介绍 | 拒绝孤独学习，一个能互相发声、互相回应的英语学习搭子：智能定级、定制方案、陪练纠错、追踪进步。 |
| 擅长领域 | 个性化学习方案 / 陪练纠错 / 阶段题库测评 |

## 核心能力（六项蒸馏）

| 能力 | 蒸馏来源 |
|---|---|
| CEFR 智能定级（自述 + 8–12 题自适应测评） | 剑桥英语 / EF SET |
| 可理解输入 i+1（生词率 10–20% 分级材料 + 旧词复现） | LingQ / Krashen 输入假说 |
| 间隔重复词汇（先考后揭 + +1/+3/+7/+16/+35 天间隔表） | Anki / FSRS |
| 坚持机制（微目标 + 连胜可视化 + 每周 1 天宽限） | Duolingo |
| 输出陪练与延后纠错（不打断流利度、会话末归类纠错、错误日志） | Cambly / ELSA |
| 显性语法微课与高频句型训练 | English Grammar in Use / Glossika |

完整方法论与证据强度见 `skills/english-learning-buddy/references/methodology.md`。

## 包结构

```
english-learning-buddy/
├── .codebuddy-plugin/plugin.json      # 专家元数据
├── agents/english-learning-buddy.md   # 主 Agent（人设/工作流/规范）
├── skills/english-learning-buddy/
│   ├── SKILL.md                       # 资产索引
│   ├── references/
│   │   ├── methodology.md             # 六项能力方法论蒸馏
│   │   └── assessment-bank.md         # 自适应测评题库 + CEFR 映射
│   └── templates/
│       ├── learning-plan.md           # 学习方案模板（首诊交付物）
│       └── learning-profile.md        # 学习档案模板（跨会话记忆载体）
├── avatars/expert.png                 # 头像
└── README.md
```

## 使用示例

- 我想学英语，帮我定级并制定一份学习方案
- 这是我的学习档案，继续今天的学习
- 陪我练一段英语对话，并纠正我的错误

## 工作流闭环

首诊定级 → 需求画像 → 生成学习方案 → 每日会话陪练（开场到期词汇复习 → i+1 当日任务 → 会话末集中纠错）→ 更新学习档案 → 用户下次贴回档案无缝续接。

## 头像

头像已自动生成在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

将专家包目录放到专家目录下：

```
/Users/admin/.workbuddy/plugins/marketplaces/my-experts/plugins/english-learning-buddy/
```

然后运行注册命令使其可见：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
zip -r english-learning-buddy.zip english-learning-buddy/
```
