---
description: 唤起表格 AI 助手，用自然语言完成 Excel 表格的读写、查询、数据分析、公式计算等操作
description_zh: "唤起表格 AI 助手，用自然语言完成 Excel 表格的读写、查询、数据分析、公式计算等操作"
description_en: "Launch the spreadsheet AI assistant to read, write, query, analyze data, calculate formulas, and perform other Excel operations using natural language."
argument-hint: "描述你想对表格做的事情，例如：帮我汇总 Q1 销售额"
---

<user_input>
$ARGUMENTS
</user_input>

---

将此任务委派给 **sheet-agent** 子代理处理。

## 传递给子代理的内容（仅限以下四项）

1. **文件路径** — 用户上传或引用的 Excel/CSV 文件的完整路径
2. **用户输入** — 用户的原始自然语言需求，原样转发，不做改写
3. **当前时间** — 主代理上下文中的当前时间信息，原样传递给子代理
4. **期望返回** — 告诉子代理需要返回什么结果给用户（如数据摘要、操作确认等）

## 禁止

- **禁止**添加实现步骤、工具名称、操作流程或任何执行细节
- **禁止**告诉子代理该如何完成任务或该调用哪些工具
- **禁止**主代理直接调用 `mcp__sheetagent__*` 工具

## 前置条件

若用户只上传了文件但没有给出具体指令，先询问用户希望做什么，得到回复后再调用子代理。

