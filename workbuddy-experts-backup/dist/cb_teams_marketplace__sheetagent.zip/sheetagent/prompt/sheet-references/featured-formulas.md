---
name: featured-formulas
description: >
  Authoritative guide to the two external-data formulas STOCK (stock quotes) and IMPORTRANGE
  (cross-sheet range import) — syntax, required params, spill/return shape, limits, the
  `#GETTING_DATA` loading state, and error codes. Read BEFORE writing any STOCK or IMPORTRANGE
  formula into a cell. Triggers on: 查股价 / 拉行情 / 股票报价 / 涨跌幅 / 实时价 / STOCK;
  从另一个表导入 / 跨表引用 / 引用某个链接的数据 / IMPORTRANGE; "stock price / quote /
  ticker", "import a range from another sheet / doc", any formula string containing `STOCK(`
  or `IMPORTRANGE(`.
description_zh: >-
  STOCK（股票行情）与 IMPORTRANGE（跨表区域导入）两个外部数据公式的权威指南：语法、必填参数、
  溢出/返回结构、限制、`#GETTING_DATA` 加载状态与错误码。在单元格中写入任何 STOCK 或 IMPORTRANGE 公式前必须阅读。
  触发词：查股价 / 拉行情 / 股票报价 / 涨跌幅 / 实时价 / STOCK；从另一个表导入 / 跨表引用 / 引用某个链接的数据 /
  IMPORTRANGE。
description_en: >-
  Authoritative guide to the two external-data formulas STOCK (stock quotes) and IMPORTRANGE (cross-sheet range
  import) — syntax, required params, spill/return shape, limits, the `#GETTING_DATA` loading state, and error codes.
  Read BEFORE writing any STOCK or IMPORTRANGE formula into a cell. Triggers on: "stock price / quote / ticker",
  "import a range from another sheet / doc", any formula string containing `STOCK(` or `IMPORTRANGE(`.
---

# 特色公式使用指南：STOCK 与 IMPORTRANGE

腾讯文档表格提供两个依赖**外部数据**的特色公式：

- **`STOCK`** —— 获取股票行情，结果会随行情实时刷新。
- **`IMPORTRANGE`** —— 从另一个在线表格导入一片区域的单元格。

它们与普通公式（如 `SUM`）的本质区别：**结果不是纯本地可得的**，需要向外部数据源发起一次拉取。Agent 只负责把正确的公式字符串写进单元格，数据拉取自动完成。

> ⚠️ 这两个函数依赖"增强能力"，部分私有化 / 受限环境可能不可用。写入前若不确定，可先说明该能力依赖服务端支持。

---

## 外部数据的加载行为（Agent 必须理解）

写入这类公式后，单元格**不会立刻**出现最终值：数据拉取完成前会短暂显示 **`#GETTING_DATA`（正在获取数据）**，这是**正常中间态，不是错误**。

不要因为看到加载状态就判定公式写错并反复重写；应等待刷新，或提示用户"数据加载中"。`STOCK` 为保证行情尽量新，会周期性地重新拉取并刷新。

---

## STOCK —— 股票报价

### 语法
```
STOCK(股票代码, 数据类型)
```
两个参数**均为必填**。

### 参数

**1. 股票代码**（字符串）
特定市场上某只公开交易股票的唯一标识，形如 `代码.市场后缀`。支持的市场后缀（大小写不敏感）：

| 后缀 | 市场 | 结算货币 |
|------|------|------|
| `.SH` | 上交所 | 人民币 ¥ |
| `.SZ` | 深交所 | 人民币 ¥ |
| `.BJ` | 北交所 | 人民币 ¥ |
| `.HK` | 港交所 | 港币 HK$ |
| `.US` | 美股 | 美元 US$ |

> B 股特例：上证 B 股（`900` 开头）、深证 B 股（`200`/`201` 开头）虽在沪深市场，但结算货币按**港币**呈现。
> 股票代码不能为空。

**2. 数据类型**（整数，取值 `0`–`8`）

| 值 | 含义 | 说明 |
|----|------|------|
| `0` | 价格 | 前一交易日**收盘价** |
| `1` | 名称 | 股票 / 公司全称 |
| `2` | 涨跌额 | 前一交易日收盘价 − 再前一日收盘价 |
| `3` | 涨跌幅 | 最近两个收盘价之间的变化百分比（自动应用百分比格式） |
| `4` | 开盘价 | 前一交易日开盘价 |
| `5` | 最高价 | 前一交易日最高价 |
| `6` | 最低价 | 前一交易日最低价 |
| `7` | 成交量 | 前一交易日成交份额数 |
| `8` | 实时价格 | 实时价；当日不开市则取前一交易日收盘价 |

### 返回值与格式
- 名称（`1`）返回字符串；其余返回数字。
- 价格类（`0/2/4/5/6/8`）会自动套用对应市场的**货币格式**；涨跌幅（`3`）自动套用**百分比格式**。Agent 无需再手动设格式。

### 示例
```
=STOCK("00700.HK", 0)     腾讯控股 前一交易日收盘价（港币）
=STOCK("00700.HK", 1)     腾讯控股 名称
=STOCK("600519.SH", 8)    贵州茅台 实时价（人民币）
=STOCK("AAPL.US", 3)      苹果 涨跌幅（百分比）
```

配合单元格引用做批量行情表也很常见：
```
=STOCK(A2, 0)             A2 存放股票代码
```

---

## IMPORTRANGE —— 跨表导入区域

### 语法
```
IMPORTRANGE(电子表格链接, 范围字符串)
```
两个参数**均为必填**，均为字符串。

### 参数

**1. 电子表格链接**（字符串）
作为数据来源的在线表格网址，如 `"https://docs.qq.com/sheet/XXXXXXXX"`。

**2. 范围字符串**（字符串）
格式为 `工作表名!范围`，例如 `"Sheet1!A2:B6"`：
- 支持整行 `Sheet1!2:2`、整列 `Sheet1!A:A`（整行/整列会补齐到表格边界）；
- 单次导入**单元格总数上限 10 万**，超出会失败。

### 返回形态（重要）
`IMPORTRANGE` 返回的是一片**区域**，会像数组公式一样**溢出（spill）**填充多个单元格。因此：
- 只需在**左上角单元格**写一次公式，其余单元格由溢出结果填充；
- 不要在会被溢出覆盖的区域再写其它内容，否则会 `#SPILL`；
- 返回的是区域，可直接被 `SUM` / `VLOOKUP` 等需要区域入参的函数引用。

### 权限说明
导入的是**另一个文档**的数据，通常需要来源表对当前用户可见 / 已授权。若来源表无权限或链接无效，数据拉取会失败。

### 示例
```
=IMPORTRANGE("https://docs.qq.com/sheet/ABCDEF1234", "Sheet1!A1:D21")
=IMPORTRANGE("https://docs.qq.com/sheet/ABCDEF1234", "汇总!A:C")
=SUM(IMPORTRANGE("https://docs.qq.com/sheet/ABCDEF1234", "Sheet1!B2:B100"))
```

---

## Agent 使用要点（写入前自检清单）

**何时使用**
- 用户要"查股价 / 拉行情 / 涨跌幅"→ `STOCK`。
- 用户要"从另一个表 / 某个链接把数据引过来"→ `IMPORTRANGE`。

**写入注意**
1. **两个参数都要给全**——`STOCK` 必须带数据类型（不要只写代码），`IMPORTRANGE` 必须带 `工作表名!范围`。
2. **字符串参数用英文双引号**包裹（代码、链接、范围字符串）。数据类型是数字，不加引号。
3. `STOCK` 数据类型只能是 `0`–`8`，按上表选对语义（价格 vs 实时价 vs 涨跌幅别混）。
4. `IMPORTRANGE` 只在**左上角**写一次，预留足够的溢出空间；估算区域大小，注意 10 万单元格上限。
5. 写入后若单元格显示**"正在获取数据"**，属正常加载中，稍候刷新即可，**不要重写公式**。
6. 依赖增强能力与外部授权；若环境不支持或来源无权限，数据拉取会失败——遇到时向用户解释原因，而非反复重试。

**错误码 / 现象对照**（单元格里显示的值）

| 单元格显示 | 触发场景 | 处理 |
|-----------|---------|------|
| `#GETTING_DATA` | 外部数据加载中，正常中间态（非错误） | 等待刷新，**勿重写公式** |
| `#VALUE!` | STOCK 股票代码为空；或 IMPORTRANGE 范围字符串格式非法 | 检查股票代码 / `工作表名!范围` 格式 |
| `#NUM!` | STOCK 数据类型不在 `0`–`8` 范围内 | 改用 `0`–`8` 的合法值 |
| `#SPILL!` | IMPORTRANGE 溢出区域已被其它内容占用 | 清空左上角以外将被填充的单元格 |
| `#ERROR!` | 环境未开启增强能力；或 IMPORTRANGE 超过 10 万单元格上限 | 说明环境不支持 / 缩小导入范围 |
| 无权限 / 不可查看提示 | IMPORTRANGE 来源表不可查看、未授权或链接无效 | 确认链接正确、来源表对当前用户已授权 |

> `#GETTING_DATA` 是加载态而非错误，不要据此重写公式；其余为真正的错误值，需按上表修正参数或环境。
