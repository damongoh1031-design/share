#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""雅思写作精批报告 → 单文件 HTML 渲染器。

用法：
    python render_report.py <spec.json> <out.html>

作用：
    把一次精批的结果渲染成**自包含单文件 HTML 报告**（内联 CSS，无外链、无 CDN）。
    其中「润色后英文」的逐段稿与全文稿，会由本脚本自动比对**学生原文 vs 润色稿**：
        · 新增或改写的词句  →  红色
        · 未改动的原文保留  →  黑色
        · 被删除的原文      →  红色删除线（可在页面上开关隐藏）
    标红一律由脚本计算得出，调用方**不得手写**标红或手动调整颜色，
    以保证「标红 = 真实改动」始终成立。

spec.json 契约（UTF-8）：
{
  "title": "雅思写作精批报告",
  "subtitle": "Task 2 · 观点选择题",
  "meta": [{"label": "题型", "value": "..."},
           {"label": "输入完整性", "value": "..."},
           {"label": "词数", "value": "未独立核实"}],
  "scores": [{"name": "TA / TR", "score": 7, "reason": "正面证据＋主要限制"}],
  "overall": {"band": "7.0", "strongest": "...", "bottleneck": "..."},
  "disclaimer": "本结果依据 IELTS 公开评分标准作教学估分，不是官方成绩。",
  "criteria": [{"name": "TA / TR", "score": 7,
                "strengths": ["..."], "weaknesses": ["..."]}],
  "paragraphs": [{"index": 1, "original": "逐字英文原文", "feedback": "中文散文反馈",
                  "polished": "润色后英文", "translation": "润色后中文翻译"}],
  "draft": {"translation": "全文中文翻译",
            "predicted": {"TA / TR": 7, "CC": 7, "LR": 7, "GRA": 7,
                          "band": "7.0", "note": "提升来源说明"}}
}

其中 scores 与 criteria 的 name 必须一致；paragraphs 是逐段对比的唯一数据源，
全文润色稿与全文标红都由 paragraphs 拼接生成，因此第 3 部分与第 4 部分天然一致。
"""

import argparse
import difflib
import html
import json
import re
import sys
from pathlib import Path

TOKEN_RE = re.compile(r"\s+|[^\s]+")

DEFAULT_DISCLAIMER = "本结果依据 IELTS 公开评分标准作教学估分，不是官方成绩。"

CSS = """
:root{
  --ink:#1f2328; --ink-soft:#3d444d; --muted:#6a737d; --line:#e4e7eb;
  --bg:#f5f6f8; --card:#ffffff; --red:#c81e1e; --red-bg:#fdeceb;
  --ok:#1a7f37; --warn:#9a6700; --accent:#1f4e79;
}
*{box-sizing:border-box;}
html{-webkit-text-size-adjust:100%;}
body{
  margin:0; background:var(--bg); color:var(--ink);
  font-family:"Microsoft YaHei","PingFang SC","Hiragino Sans GB","Segoe UI",system-ui,-apple-system,sans-serif;
  font-size:15px; line-height:1.8;
  -webkit-font-smoothing:antialiased;
}
.wrap{max-width:920px; margin:0 auto; padding:30px 22px 70px;}
header.head{margin-bottom:20px;}
h1{font-size:26px; line-height:1.35; margin:0 0 8px; letter-spacing:.5px;}
.sub{margin:0; color:var(--muted); font-size:14px;}
h2{
  font-size:18px; margin:34px 0 14px; padding-left:12px;
  border-left:4px solid var(--accent); line-height:1.4;
}
h3{font-size:16px; margin:0 0 12px; line-height:1.5;}
.card{background:var(--card); border:1px solid var(--line); border-radius:10px; padding:20px 22px;}
.toolbar{
  display:flex; flex-wrap:wrap; align-items:center; gap:8px 22px;
  background:var(--card); border:1px solid var(--line); border-radius:10px;
  padding:10px 16px; margin-bottom:6px; font-size:13px; color:var(--muted);
}
.toolbar label{cursor:pointer; user-select:none;}
.legend em{font-style:normal;}
.lk{color:var(--red); font-weight:700;}
.lb{color:var(--ink); font-weight:700;}
.meta-list{margin:0; padding:0; list-style:none; font-size:14px;}
.meta-list li{padding:5px 0; border-bottom:1px dashed var(--line);}
.meta-list li:last-child{border-bottom:0;}
.meta-list b{display:inline-block; min-width:82px; color:var(--muted); font-weight:400;}
table{width:100%; border-collapse:collapse; margin:16px 0 6px; font-size:14px;}
th,td{border:1px solid var(--line); padding:9px 11px; vertical-align:top; text-align:left;}
th{background:#f0f2f5; font-weight:600; white-space:nowrap;}
td.num{text-align:center; font-weight:700; width:78px; white-space:nowrap;}
.overall{margin:14px 0 0; padding:0; list-style:none; font-size:14.5px;}
.overall li{padding:4px 0;}
.overall b{color:var(--muted); font-weight:400;}
.band{
  display:inline-block; background:#eef4fb; color:var(--accent); border:1px solid #cfe0f2;
  border-radius:6px; padding:1px 10px; font-weight:700;
}
.note{
  margin:16px 0 0; padding:10px 14px; border-left:3px solid var(--line);
  background:#fafbfc; color:var(--muted); font-size:13px; border-radius:0 6px 6px 0;
}
.crit{background:var(--card); border:1px solid var(--line); border-radius:10px; padding:18px 20px; margin-bottom:14px;}
.crit .ch{display:flex; align-items:baseline; justify-content:space-between; gap:12px;}
.crit .sc{color:var(--accent); font-weight:700; font-size:15px; white-space:nowrap;}
.crit h3{color:var(--accent); margin:0;}
.crit .ar{font-size:14px; margin:12px 0 0;}
.crit .ar span{display:inline-block; min-width:60px;}
.crit ul{margin:6px 0 0; padding-left:22px;}
.crit li{margin:4px 0;}
.para{background:var(--card); border:1px solid var(--line); border-radius:10px; padding:18px 20px 6px; margin-bottom:16px;}
.block{margin-bottom:16px;}
.bt{font-size:13px; font-weight:700; color:var(--muted); letter-spacing:.4px; margin-bottom:6px;}
.bt .cnt{font-weight:400; color:var(--red); margin-left:8px;}
blockquote{margin:0; padding:12px 15px; border-left:3px solid var(--line); background:#fafbfc; border-radius:0 6px 6px 0;}
.en{font-family:Georgia,"Times New Roman","Songti SC",serif; font-size:15.5px; line-height:1.85;}
.zh{font-size:14.5px; color:var(--ink-soft);}
.fb{margin:0; font-size:14.5px; line-height:1.85;}
.fb code, .zh code, td code{
  font-family:Consolas,"Courier New",monospace; font-size:13px;
  background:#f0f2f5; border:1px solid #e2e5e9; border-radius:4px; padding:0 4px;
}
ins.c{color:var(--red); background:var(--red-bg); text-decoration:none; border-radius:2px; padding:0 1px;}
del.c{color:var(--red); text-decoration:line-through; opacity:.7;}
#showdel:not(:checked) ~ .wrap del{display:none;}
.draft .en p{margin:0 0 12px;}
.draft .zh p{margin:0 0 12px;}
.pred{margin:16px 0 0; padding:0; list-style:none; font-size:14.5px;}
.pred li{padding:4px 0;}
footer.foot{margin-top:34px; color:var(--muted); font-size:12.5px; text-align:center;}
@media print{
  body{background:#fff; font-size:12pt;}
  .wrap{max-width:none; padding:0;}
  .toolbar{display:none;}
  .card,.crit,.para{break-inside:avoid;}
  #showdel:not(:checked) ~ .wrap del{display:inline;}
}
"""


def tokenize(text):
    return TOKEN_RE.findall(text or "")


def mark_changes(original, polished):
    """比对原文与润色稿，返回 (html 片段, 改动块数)。红色=改动，黑色=保留。"""
    a, b = tokenize(original), tokenize(polished)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    out, n = [], 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            out.append(html.escape("".join(b[j1:j2])))
        elif tag == "insert":
            out.append('<ins class="c">%s</ins>' % html.escape("".join(b[j1:j2])))
            n += 1
        elif tag == "delete":
            out.append('<del class="c">%s</del>' % html.escape("".join(a[i1:i2])))
            n += 1
        else:
            out.append(
                '<del class="c">%s</del><ins class="c">%s</ins>'
                % (html.escape("".join(a[i1:i2])), html.escape("".join(b[j1:j2])))
            )
            n += 1
    return "".join(out), n


def esc(text):
    return html.escape(str(text if text is not None else ""))


def inline(text):
    """渲染反馈正文：反引号 → <code>，其余转义；保留换行。"""
    text = str(text if text is not None else "")
    parts = text.split("`")
    buf = []
    for i, piece in enumerate(parts):
        buf.append("<code>%s</code>" % esc(piece) if i % 2 else esc(piece))
    return "".join(buf).replace("\n", "<br>")


def render_meta(meta):
    if not meta:
        return ""
    rows = "".join(
        "<li><b>%s</b>%s</li>" % (esc(m.get("label", "")), esc(m.get("value", "")))
        for m in meta
    )
    return '<ul class="meta-list">%s</ul>' % rows


def render_scores(scores):
    if not scores:
        return ""
    rows = "".join(
        "<tr><td>%s</td><td class=\"num\">%s</td><td>%s</td></tr>"
        % (esc(s.get("name", "")), esc(s.get("score", "")), inline(s.get("reason", "")))
        for s in scores
    )
    return (
        "<table><thead><tr><th>评分维度</th><th>预估分数</th><th>评分依据</th></tr></thead>"
        "<tbody>%s</tbody></table>" % rows
    )


def render_overall(overall):
    if not overall:
        return ""
    items = []
    band = overall.get("band") or overall.get("band_line")
    if band:
        band_txt = str(band)
        if len(band_txt.replace(".", "").strip()) <= 4 and re.match(r"^[0-9.\s]+$", band_txt.strip()):
            band_html = '<span class="band">%s</span>' % esc(band_txt.strip())
        else:
            band_html = esc(band_txt)
        items.append("<li><b>参考分</b>%s</li>" % band_html)
    for key, label in (("strongest", "最强项"), ("bottleneck", "当前最大瓶颈")):
        if overall.get(key):
            items.append("<li><b>%s</b>%s</li>" % (label, inline(overall.get(key))))
    return '<ul class="overall">%s</ul>' % "".join(items)


def render_criteria(criteria):
    blocks = []
    for c in criteria or []:
        st = c.get("strengths") or []
        wk = c.get("weaknesses") or []
        head = (
            '<div class="ch"><h3>%s</h3><div class="sc">%s 分</div></div>'
            % (esc(c.get("name", "")), esc(c.get("score", "")))
            if c.get("score") not in (None, "")
            else "<h3>%s</h3>" % esc(c.get("name", ""))
        )
        body = []
        if st:
            body.append(
                '<div class="ar"><span>✅ 亮点：</span></div><ul>%s</ul>'
                % "".join("<li>%s</li>" % inline(x) for x in st)
            )
        if wk:
            body.append(
                '<div class="ar"><span>⚠️ 不足：</span></div><ul>%s</ul>'
                % "".join("<li>%s</li>" % inline(x) for x in wk)
            )
        blocks.append('<section class="crit">%s%s</section>' % (head, "".join(body)))
    return "".join(blocks)


def render_paragraphs(paragraphs):
    blocks, total = [], 0
    for p in paragraphs or []:
        marked, n = mark_changes(p.get("original", ""), p.get("polished", ""))
        total += n
        idx = p.get("index")
        title = "第 %s 段" % esc(idx) if idx not in (None, "") else "本段"
        cnt = "改动 %d 处" % n if n else "未改动"
        blocks.append(
            '<section class="para">'
            "<h3>%s</h3>"
            '<div class="block"><div class="bt">逐段批改</div>'
            '<blockquote class="en">%s</blockquote></div>'
            '<div class="block"><div class="bt">反馈</div><p class="fb">%s</p></div>'
            '<div class="block"><div class="bt">润色后英文<span class="cnt">%s</span></div>'
            '<blockquote class="en">%s</blockquote></div>'
            '<div class="block"><div class="bt">润色后中文翻译</div>'
            '<blockquote class="zh">%s</blockquote></div>'
            "</section>"
            % (
                title,
                esc(p.get("original", "")),
                inline(p.get("feedback", "")),
                cnt,
                marked,
                inline(p.get("translation", "")),
            )
        )
    return "".join(blocks), total


def render_draft(paragraphs, draft):
    marked_paras, total = [], 0
    for p in paragraphs or []:
        marked, n = mark_changes(p.get("original", ""), p.get("polished", ""))
        total += n
        marked_paras.append('<p class="en">%s</p>' % marked)
    translation = (draft or {}).get("translation", "")
    trans_html = "".join(
        '<p class="zh">%s</p>' % inline(x)
        for x in re.split(r"\n\s*\n", translation.strip())
        if x.strip()
    )
    pred = (draft or {}).get("predicted") or {}
    lines = []
    four = [(k, pred.get(k)) for k in ("TA / TR", "TR", "TA", "CC", "LR", "GRA")]
    four = [(k, v) for k, v in four if v not in (None, "")]
    if four:
        lines.append(
            "<li><b>润色后四项预估</b>%s</li>"
            % esc("、".join("%s %s" % (k, v) for k, v in four))
        )
    if pred.get("band"):
        lines.append(
            '<li><b>润色后参考分</b><span class="band">%s</span></li>'
            % esc(pred.get("band"))
        )
    if pred.get("note"):
        lines.append("<li><b>提升来源</b>%s</li>" % inline(pred.get("note")))
    cnt = "全文改动 %d 处" % total if total else "未改动"
    return (
        '<div class="draft"><div class="bt">润色后英文全文<span class="cnt">%s</span></div>'
        '%s<div class="bt" style="margin-top:18px;">中文翻译</div>%s</div>'
        "%s"
        % (
            cnt,
            "".join(marked_paras) or '<p class="en"></p>',
            trans_html,
            '<ul class="pred">%s</ul>' % "".join(lines) if lines else "",
        )
    )


def build_html(spec):
    title = spec.get("title") or "雅思写作精批报告"
    subtitle = spec.get("subtitle") or ""
    paragraphs = spec.get("paragraphs") or []
    draft = spec.get("draft") or {}
    para_html, _ = render_paragraphs(paragraphs)
    draft_html = render_draft(paragraphs, draft)

    return (
        "<!DOCTYPE html>\n"
        '<html lang="zh-CN">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
        "<title>%s</title>\n<style>%s</style>\n</head>\n<body>\n"
        '<input type="checkbox" id="showdel" checked hidden>\n'
        '<div class="wrap">\n'
        '<header class="head"><h1>%s</h1>%s</header>\n'
        '<div class="toolbar">'
        '<label><input type="checkbox" id="showdel-ui" checked> 显示被删除的原文</label>'
        '<span class="legend"><em class="lk">标红</em> = 润色改动　'
        '<em class="lb">黑色</em> = 原文保留</span>'
        "</div>\n"
        "<main>\n"
        '<section><h2>1. 📊 评分结果</h2><div class="card">%s%s%s<div class="note">%s</div></div></section>\n'
        '<section><h2>2. 🔍 四项分项得分分析</h2>%s</section>\n'
        '<section><h2>3. ✍️ 逐段精批与润色</h2>%s</section>\n'
        '<section><h2>4. 📈 润色后全文与预估</h2><div class="card">%s</div></section>\n'
        "</main>\n"
        '<footer class="foot">%s</footer>\n'
        "</div>\n<script>%s</script>\n</body>\n</html>\n"
        % (
            esc(title),
            CSS,
            esc(title),
            ('<p class="sub">%s</p>' % esc(subtitle)) if subtitle else "",
            render_meta(spec.get("meta")),
            render_scores(spec.get("scores")),
            render_overall(spec.get("overall")),
            esc(spec.get("disclaimer") or DEFAULT_DISCLAIMER),
            render_criteria(spec.get("criteria")),
            para_html or '<div class="card">（无段落数据）</div>',
            draft_html,
            esc(spec.get("footer") or DEFAULT_DISCLAIMER),
            "var c=document.getElementById('showdel'),u=document.getElementById('showdel-ui');"
            "if(u){u.checked=c.checked;u.addEventListener('change',function(){c.checked=u.checked;});}",
        )
    )


def main():
    ap = argparse.ArgumentParser(description="Render IELTS grading report to a single-file HTML.")
    ap.add_argument("spec", help="path to spec.json (UTF-8)")
    ap.add_argument("out", help="path to the output .html")
    args = ap.parse_args()

    spec_path = Path(args.spec)
    if not spec_path.exists():
        print("spec not found: %s" % spec_path, file=sys.stderr)
        return 1
    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print("invalid JSON in spec: %s" % e, file=sys.stderr)
        return 1

    paragraphs = spec.get("paragraphs") or []
    if not paragraphs:
        print("warning: spec has no 'paragraphs'; the diff sections will be empty.", file=sys.stderr)
    for i, p in enumerate(paragraphs, 1):
        if not p.get("polished"):
            print("warning: paragraph %s has no 'polished' text." % p.get("index", i), file=sys.stderr)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(build_html(spec), encoding="utf-8")
    print("written: %s (%d bytes)" % (out_path, out_path.stat().st_size))
    return 0


if __name__ == "__main__":
    sys.exit(main())
