---
name: ielts-writing-grading
version: 1.4.0
display_name: 雅思写作评分量表
display_name_en: IELTS Writing Grading Rubric
description: Detailed reference rubric for IELTS Academic / General Training Writing Task 1 and Task 2, loaded on demand by the "IELTS Writing Grading Expert" while grading. Covers the four-criteria band descriptors, the 36-point to band conversion table, input routing, the output contract of the fixed four-section report plus a single-file HTML report whose polished text is automatically diff-marked in red against the original, concise coach-style Chinese feedback, the dual-track polishing discipline (language optimisation plus task-response completion), question-type rules, and cross-dimension attribution guards.
description_zh: 雅思写作精批的详细参考依据。含四项评分维度（TA/TR、CC、LR、GRA）档位口径、四项合计—参考分换算表、输入路由（文字/照片/截图）、四段式报告的输出合同与视觉标记、精简版教练式散文反馈规范（3–5 句、第二人称、语言与任务问题分开陈述、不复述改动）、单文件 HTML 报告的渲染契约（润色稿自动标红对比，红＝改动、黑＝原文保留）、双修润色纪律（语言优化 + 任务回应补足，可增删改以提升 TA/TR）、三类题型分流规则，以及逐字证据、归因纯度、静态图表防趋势误读等跨维度护栏。
agent_created: true
---

# 雅思写作评分量表（详细参考）

本文件为「雅思作文精批专家」的内置详细评分依据，批改时按需载入。

> 评分维度：**Academic Task 1 / General Training Task 1 → TA、CC、LR、GRA；Task 2 → TR、CC、LR、GRA**。
> 核心逻辑：**四项独立评分、先证据后判断；任何判断都必须能回到题目或原文**。
> 词数恒记为 `未独立核实`；结果为**教学估分**，不代表官方成绩。

完整内容见 `references/full-instructions.md`，含：

- **输入路由**：不支持的输入 > 新清晰照片 > 等待确认 > 修改稿复评 > 新作文批改 > 写前辅导
- **最终输出硬锁 30 条**：输出门、逐字引文、归因纯度、静态图表防趋势误读、精简版教练式散文反馈规范、双修润色纪律（可增删改，透明由 HTML 呈现）、视觉标记与报告终止位置等
- **评分流程 17 步自查**与**四项合计—参考分换算表**
- **固定报告模板**（第 1 部分评分结果 / 第 2 部分四项分项得分分析 / 第 3 部分逐段精批与润色 / 第 4 部分润色后全文与预估分）、**HTML 报告契约**（`scripts/render_report.py` + spec.json 字段表）与**其他模式**（快速批改 / 仅估分 / 写前辅导 / 修改稿复评）
- **生产与评测隔离**原则
