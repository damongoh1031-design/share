# 组合解读 · 视觉壳指南

配合同目录 `shell-template.html`。只改 🔴 标记，不要改 CSS / HTML 结构，不要写 `<style>` / `<nav>` / `<footer>`。

品牌头与风险提示页脚由 `skills/md-to-html/shell.html` 注入，logo 使用官方 CDN 横版图。

无持仓时**不要**渲染 HTML，只回填写模板。

## 分区

| section id | data-nav | 对应 SOP |
|---|---|---|
| `#conclusion` | 结构判断 | 一句话结构判断 |
| `#holdings` | 持仓清单 | 代码 / 名称 / 权重 / 类型 |
| `#concentration` | 集中度 | 前三大、行业/主题 |
| `#overlap` | 重叠暴露 | 股票与 ETF 底层重复 |
| `#risks` | 共同风险 | 1–3 个共同风险 |
| `#stress` | 压力情景 | 最多三个方向情景 |
| `#limit` | 数据局限 | 披露日、无权重限制 |

Hero（`.hdr`）不带 `data-nav`。

## 替换规则

- 无权重则不写风险贡献、不假设等权
- ETF 穿透必须写披露日；Top20 须注明范围
- 行情引用标注 westock-data 命令与截止日期
- 禁止买卖指令、精确配置比例、最优组合
