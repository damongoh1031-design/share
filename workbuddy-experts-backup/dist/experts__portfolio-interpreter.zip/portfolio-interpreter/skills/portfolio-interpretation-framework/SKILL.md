---
name: portfolio-interpretation-framework
description: |
  【投资组合解读官专属知识库】解读用户粘贴的股票/ETF 组合：集中度、重复暴露、风格与共同风险、历史波动/回撤/相关性、压力情景。
  由 投资组合解读官 读取。读不到账户。不做最优配置、不给精确仓位比例。
---

# 投资组合解读知识库

> SOP 与无持仓门禁在 Role。这里只做导航、westock-data 路由和证据分级。
> **覆盖层优先**：`references/asset-allocation/main.md` 只作风险视角索引。忽略文内组合优化、MVO、Black-Litterman、最优风险平价、精确配置比例与择时建仓。

运行时路径前缀：`skills/portfolio-interpretation-framework/references/`。

有持仓的正式解读先写对话 md，再按 `skills/md-to-html` 套壳产出 HTML 面板。无持仓不渲染。

## 原始框架来源

主体沿用 `asset-allocation`，只保留适合「解读已粘贴组合」的模块。

| 文件 | 用途 |
|---|---|
| `asset-allocation/main.md` | 风险视角；触发条件和能力边界以本 Skill / Role 为准 |
| `asset-allocation/ref-portfolio-process.md` | 目标约束、组合构建、再平衡、归因思想 → 改造成解读流程 |
| `asset-allocation/ref-risk-parity.md` | 资本权重 ≠ 风险贡献；**不计算最优风险平价权重** |
| `asset-allocation/ref-equity-bond-dynamics.md` | 相关性变化、同跌、分散失效 |
| `asset-allocation/ref-valuation-timing.md` | 组合整体估值风险；**不输出择时和建仓指令** |
| `asset-allocation/ref-asset-class-analysis.md` | 不同资产或 ETF 的风险来源 |
| `asset-allocation/ref-china-context.md` | 中国市场政策、信用和流动性风险 |
| `asset-allocation/ref-micro-foundation.md` | 参与者、市场结构、风险传导 |

**禁止执行**：MVO、Black-Litterman、最优风险平价权重和杠杆、机构实践、完整 Brinson、精确配置比例和自动再平衡。

## 问题路由

| 用户问题 | 先读 | 再按需读 |
|---|---|---|
| 有没有持仓、权重是否齐全 | Role 中的填写模板（无持仓即停） | `asset-allocation/main.md` |
| 集中度 / 前三大占比 | `ref-portfolio-process.md` | `ref-risk-parity.md` |
| ETF 与股票是否重复 | `ref-asset-class-analysis.md` | `ref-portfolio-process.md` |
| 行业/主题/风格偏向 | `ref-china-context.md` | `ref-asset-class-analysis.md` |
| 波动、回撤、相关性、风险贡献 | `ref-risk-parity.md` | `ref-equity-bond-dynamics.md` |
| 压力情景 / 同跌 | `ref-equity-bond-dynamics.md` | `ref-micro-foundation.md` |

## westock-data 命令路由

| 步骤 | 命令 |
|---|---|
| 名称解析 | `search`（ETF 用 `--type etf`） |
| 行情 | `quote` 批量 |
| 历史收益 | `kline --period day`，对齐交易日 |
| 股票行业 | `profile` |
| ETF | `etf detail` / `etf holdings`（写披露日） |
| 估值 | `market-overview --type valuation` / `sector valuation` |

无账户 API。无持仓不调行情。westock-data 由平台注入，行情与穿透优先走 westock-mcp；不可用或 `search` 失败时可用其他来源补充并标注，都取不到时写「暂无可靠数据」，不编造穿透或相关性。引用行情/K 线/估值时标注命令与截止日期。

## 数据证据分级

| 等级 | 条件 | 允许输出 |
|---|---|---|
| A | 有标的、有权重、行情/K 线可得 | 结构解读、风险贡献近似、压力方向 |
| B | 有标的、无权重 | 成分/行业/主题/ETF 重复；**不得等权、不算风险贡献** |
| C | ETF 仅 Top20 | 有限穿透，注明范围 |
| D | 无持仓 | **只回填写模板** |

## 按需读取

1. 单一问题 1～3 个 Reference，综合 3～5 个。先 `main.md` 再 `ref-*`。禁止整库加载。
2. 原始框架历史数字只作案例。
