/*
 * kline-runtime.js — 数据驱动的 K 线图运行时（固定逻辑，模型不碰）。
 *
 * 模型只在 body 片段里放一个 JSON 数据岛（script 标签 type=application/json、id=kline-data，内含 raw/baseLines/basePoints/dims）。
 * 本运行时由 render.py 在检测到该数据岛时注入 head，DOM 就绪后读取 JSON 画图、渲染维度、绑定联动。
 * 注意：本文件会被内联进 head 的 script 标签，正文里严禁出现字面量结束标签（会提前截断脚本）。
 * 这样模型产出的只有「可被 JSON.parse 校验的数据」，不再手写易错的图表 JS（括号配平崩溃）。
 *
 * 数据 schema 见 skills/industry-analysis-framework/references/ref-visual-shell.md「K 线数据岛」一节。
 */
(function () {
  // 数据岛文案由模型产出，拼进 innerHTML 前统一转义，避免 < > & " 破坏 DOM 结构。
  function esc(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function boot() {
    var dataEl = document.getElementById("kline-data");
    if (!dataEl || typeof echarts === "undefined") {
      return;
    }
    var D;
    try {
      D = JSON.parse(dataEl.textContent || "{}");
    } catch (e) {
      console.error("[kline] 数据岛 JSON 解析失败：", e);
      return;
    }

    var raw = Array.isArray(D.raw) ? D.raw : [];
    var chartEl = document.getElementById("chart");
    var volEl = document.getElementById("volchart");
    if (!raw.length || !chartEl || !volEl) {
      return;
    }

    var dates = raw.map(function (r) {
      return r[0];
    });
    // raw 每行 = [日期, 开, 收, 高, 低, 量]；ECharts candlestick 需 [开, 收, 低, 高]。
    var ohlc = raw.map(function (r) {
      return [r[1], r[2], r[4], r[3]];
    });
    var lastIdx = raw.length - 1;

    function idxOfDate(d) {
      if (d === "__LAST__" || d == null) {
        return lastIdx;
      }
      return raw.findIndex(function (r) {
        return r[0] === d;
      });
    }
    function ma(n) {
      var a = [];
      for (var i = 0; i < raw.length; i++) {
        if (i < n - 1) {
          a.push("-");
          continue;
        }
        var s = 0;
        for (var j = 0; j < n; j++) {
          s += raw[i - j][2];
        }
        a.push(+(s / n).toFixed(2));
      }
      return a;
    }

    var chart = echarts.init(chartEl);
    var volchart = echarts.init(volEl);

    function lbl(t, bg) {
      return {
        formatter: t,
        fontSize: 10,
        color: "#fff",
        backgroundColor: bg,
        padding: [2, 5],
        borderRadius: 4,
      };
    }

    // 默认压力/支撑线（faded=有维度激活时淡化；mute=该维度自带标注，基准线只留细线不留字，避免与维度自己的标签重复打架）。
    function baseLines(faded, mute) {
      return (D.baseLines || []).map(function (L) {
        var res = L.side === "res";
        var col = res ? (faded ? "#e2b8b4" : "#c0392b") : faded ? "#b6d4c8" : "#0f8a5f";
        return {
          yAxis: L.y,
          lineStyle: { color: col, width: L.width || 1, type: L.type || "dashed" },
          label: mute
            ? { show: false }
            : {
                formatter: L.label || "",
                color: col,
                position: L.pos || (res ? "insideEndTop" : "insideStartBottom"),
                fontSize: 10,
                fontWeight: "normal",
                backgroundColor: "rgba(255,255,255,0.82)",
                padding: [2, 4],
                borderRadius: 3,
              },
        };
      });
    }
    // 默认底部/今日标记点（kind: bottom=绿, today=红）。
    function basePoints(faded) {
      return (D.basePoints || []).map(function (P) {
        var bottom = P.kind === "bottom";
        var color = faded ? (bottom ? "#bcd3c8" : "#e0c2bf") : bottom ? "#0f8a5f" : "#c0392b";
        var bg = faded ? (bottom ? "#9fbcae" : "#c9a9a5") : bottom ? "#0f8a5f" : "#c0392b";
        var text = faded ? P.fadedLabel || (bottom ? "底" : "今") : P.label || "";
        return {
          coord: [idxOfDate(P.date), P.y],
          itemStyle: { color: color },
          symbolSize: faded ? 22 : P.size || 34,
          label: lbl(text, bg),
        };
      });
    }

    // 声明式 series → ECharts series：ma=自动算均线；polyline=按 date→y 连折线。
    function buildSeries(spec) {
      if (spec.kind === "ma") {
        var name = spec.label || "MA" + spec.period;
        // 不画 endLabel：线名由 banner 说明（"紫线=MA20…"），端标签会和右侧价格轴数字叠在一起。
        return {
          name: name,
          type: "line",
          data: ma(spec.period),
          smooth: true,
          showSymbol: false,
          lineStyle: { color: spec.color, width: spec.width || 2.4 },
        };
      }
      if (spec.kind === "polyline") {
        var map = {};
        (spec.points || []).forEach(function (p) {
          map[idxOfDate(p.date)] = p.y;
        });
        return {
          name: spec.label || "line",
          type: "line",
          smooth: spec.smooth === true,
          showSymbol: false,
          connectNulls: true,
          lineStyle: { color: spec.color, width: spec.width || 2.4 },
          data: dates.map(function (_, i) {
            return i in map ? map[i] : "-";
          }),
        };
      }
      return null;
    }
    function buildMarkLines(arr) {
      return (arr || []).map(function (L) {
        var line = {
          lineStyle: { color: L.color, width: L.width || 1.5, type: L.type || "dashed" },
          label: !L.label
            ? { show: false }
            : {
                formatter: L.label,
                color: L.labelColor || L.color,
                position: L.pos || "insideEndTop",
                fontSize: L.fontSize || 11,
                fontWeight: L.bold === false ? "normal" : "bold",
                // 半透明白底小药丸：标签压在 K 线/网格上时仍清晰，且不与线条糊成一团。
                backgroundColor: "rgba(255,255,255,0.82)",
                padding: [2, 4],
                borderRadius: 3,
              },
        };
        if (L.xDate != null) {
          line.xAxis = idxOfDate(L.xDate);
        } else {
          line.yAxis = L.y;
        }
        return line;
      });
    }
    function buildMarkPoints(arr) {
      return (arr || []).map(function (P) {
        // 气泡上限 30：过大的 pin 会盖住 K 线柱。
        var size = Math.min(P.size || 32, 30);
        return {
          coord: [idxOfDate(P.date), P.y],
          itemStyle: { color: P.color },
          symbolSize: size,
          label: lbl(P.label || "", P.color),
        };
      });
    }

    function render(draw) {
      var foc = !!draw && (draw.focus === true || !!(draw.series || draw.lines || draw.points));
      // 维度自带线/点时，基准线静音(只留细线)、基准点不显示——当前维度独占图上标注，杜绝重复标签互相遮挡。
      var ownsAnnotations = !!(draw && (draw.lines || draw.points));
      var extraSeries = draw && draw.series ? draw.series.map(buildSeries).filter(Boolean) : [];
      var extraMarkLine = draw && draw.lines ? buildMarkLines(draw.lines) : [];
      var extraMarkPoint = draw && draw.points ? buildMarkPoints(draw.points) : [];
      var basePointData = ownsAnnotations ? [] : basePoints(foc);
      var series = [
        {
          name: "K线",
          type: "candlestick",
          data: ohlc,
          barMaxWidth: 9,
          itemStyle: {
            color: "#e8473f",
            color0: "#16a34a",
            borderColor: "#e8473f",
            borderColor0: "#16a34a",
          },
          markLine: { symbol: "none", data: baseLines(foc, ownsAnnotations).concat(extraMarkLine) },
          markPoint: { data: basePointData.concat(extraMarkPoint) },
        },
      ].concat(extraSeries);
      chart.clear();
      chart.setOption({
        animation: true,
        grid: { left: 44, right: 92, top: 22, bottom: 24 },
        xAxis: {
          type: "category",
          data: dates,
          boundaryGap: true,
          axisLine: { lineStyle: { color: "#E8E4DE" } },
          axisLabel: { color: "#8A8480", fontSize: 11, interval: 9 },
        },
        yAxis: {
          scale: true,
          position: "right",
          splitLine: { lineStyle: { color: "#EFEAE3" } },
          axisLabel: { color: "#8A8480", fontSize: 11 },
        },
        tooltip: {
          trigger: "axis",
          axisPointer: { type: "cross" },
          confine: true,
          textStyle: { fontSize: 12 },
          formatter: function (p) {
            var k = null;
            p.forEach(function (it) {
              if (it.seriesType === "candlestick") {
                k = it;
              }
            });
            if (!k) {
              return "";
            }
            var d = k.data;
            return (
              "<b>" +
              k.axisValue +
              "</b><br/>开" +
              d[1] +
              " 收" +
              d[2] +
              "<br/>低" +
              d[3] +
              " 高" +
              d[4]
            );
          },
        },
        series: series,
      });
    }
    function renderVol(hiIdx) {
      var vols = raw.map(function (r, i) {
        var c = r[2] >= r[1] ? "#e8473f" : "#16a34a";
        if (hiIdx != null && i !== hiIdx) {
          c = r[2] >= r[1] ? "#f3b6b2" : "#a8d8bd";
        }
        return { value: r[5], itemStyle: { color: c } };
      });
      volchart.clear();
      volchart.setOption({
        animation: false,
        grid: { left: 44, right: 92, top: 18, bottom: 6 },
        title: {
          text: "成交量(万手)",
          left: 44,
          top: 0,
          textStyle: { color: "#8A8480", fontSize: 10, fontWeight: "normal" },
        },
        xAxis: {
          type: "category",
          data: dates,
          axisLabel: { show: false },
          axisTick: { show: false },
          axisLine: { lineStyle: { color: "#E8E4DE" } },
        },
        // 副图仅 52px 高，默认 5 段刻度会把 y 轴数字挤成一坨；splitNumber:1 + 只留首尾，给个量级参考即可。
        yAxis: {
          position: "right",
          splitLine: { show: false },
          splitNumber: 1,
          axisLabel: { color: "#8A8480", fontSize: 10, showMinLabel: false },
        },
        tooltip: { trigger: "axis", confine: true, textStyle: { fontSize: 12 } },
        series: [{ name: "量", type: "bar", data: vols, barMaxWidth: 9 }],
      });
    }

    var dims = Array.isArray(D.dims) ? D.dims : [];
    var list = document.getElementById("dimlist");
    var banner = document.getElementById("banner");
    var idleText = "点下方带 ● 标记的维度，图上会画出对应的依据线。";
    var activeEl = null;
    var firstDrawEl = null;

    function chipsHtml(arr) {
      return (
        '<div class="data">' +
        (arr || [])
          .map(function (c) {
            var cls = c[2] ? " " + esc(c[2]) : "";
            return '<span class="chip' + cls + '">' + esc(c[0]) + "<b>" + esc(c[1]) + "</b></span>";
          })
          .join("") +
        "</div>"
      );
    }
    function applyDraw(d) {
      render(d.draw);
      renderVol(d.draw && d.draw.volHighlight != null ? idxOfDate(d.draw.volHighlight) : undefined);
      return (d.draw && d.draw.msg) || "";
    }
    function activate(el, d) {
      if (activeEl) {
        activeEl.classList.remove("active");
      }
      el.classList.add("active");
      el.classList.remove("hintpulse");
      activeEl = el;
      var msg = applyDraw(d);
      if (banner) {
        banner.className = "banner";
        banner.textContent = msg;
      }
    }

    if (list) {
      // Agent 误把 .dim 卡片写进 #dimlist 时，运行时仍应只保留 JSON 驱动的一套。
      list.innerHTML = "";
      dims.forEach(function (d, i) {
        var el = document.createElement("div");
        var canDraw = !!d.draw;
        el.className = "dim" + (canDraw ? " clickable" : "");
        var seeimg = canDraw ? '<span class="seeimg"><span class="pin">●</span></span>' : "";
        // 数据岛里的文案全部转义后再拼：模型写的字符串可能含 < > & "，直接拼会破坏结构。
        el.innerHTML =
          '<div class="idxnum">' +
          (i + 1) +
          '</div><div class="dimmain">' +
          '<div class="dimrow"><span class="dot ' +
          esc(d.dir) +
          '"></span><span class="dn">' +
          esc(d.n) +
          '</span><span class="pill ' +
          esc(d.dir) +
          '">' +
          esc(d.dt) +
          "</span>" +
          seeimg +
          "</div>" +
          '<div class="dd" style="font-weight:500;color:#1d1d1f;margin-bottom:2px;">' +
          esc(d.concl) +
          "</div>" +
          chipsHtml(d.chips) +
          '<div class="dd" style="color:#6a6a6f;">' +
          esc(d.read) +
          "</div></div>";
        if (canDraw) {
          if (!firstDrawEl) {
            firstDrawEl = { el: el, d: d };
          }
          el.onclick = function () {
            if (activeEl === el) {
              el.classList.remove("active");
              activeEl = null;
              if (banner) {
                banner.className = "banner idle";
                banner.textContent = idleText;
              }
              render(null);
              renderVol();
              return;
            }
            activate(el, d);
          };
        }
        list.appendChild(el);
      });
    }

    render(null);
    renderVol();
    if (banner) {
      banner.className = "banner idle";
      banner.textContent = idleText;
    }
    if (firstDrawEl) {
      activate(firstDrawEl.el, firstDrawEl.d);
      document.querySelectorAll(".dim.clickable").forEach(function (x) {
        if (x !== firstDrawEl.el) {
          x.classList.add("hintpulse");
        }
      });
    }
    window.addEventListener("resize", function () {
      chart.resize();
      volchart.resize();
    });
  }

  // echarts CDN 在 <head> 同步加载，故 DOM 就绪即可保证图表库与容器都在。
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
