#!/usr/bin/env python3
from __future__ import annotations
_E='<\\\\/\\1'
_D='</(script)'
_C='utf-8'
_B=True
_A=None
import argparse,os,datetime,html,json,re,subprocess,sys
from pathlib import Path
SCRIPT_DIR=Path(__file__).resolve().parent
SHELL_PATH=SCRIPT_DIR.parent/'shell.html'
PLUGIN_ROOT=SCRIPT_DIR.parents[2]
INIT_TASK=PLUGIN_ROOT/'bin'/'init_task.py'
CDN_MAP_PATH=SCRIPT_DIR.parent/'avatar-cdn.json'
KLINE_RUNTIME_PATH=SCRIPT_DIR/'kline-runtime.js'
SKILLS_DEFAULT=SCRIPT_DIR.parent.parent
PANEL_CSS=SKILLS_DEFAULT/'portfolio-interpretation-framework'/'references'/'panel.css'
KLINE_DATA_ID='kline-data'
KLINE_DATA_RE=re.compile('<script\\b[^>]*\\bid="kline-data"[^>]*>(.*?)</script>',re.IGNORECASE|re.DOTALL)
AVATAR_IMG_RE=re.compile('<img\\b[^>]*?src="avatars/([^"/]+)\\.png"[^>]*?>')
SECTION_OPEN_RE=re.compile('<section\\b[^>]*>',re.IGNORECASE)
ATTR_ID_RE=re.compile('\\bid="([^"]+)"')
ATTR_NAV_RE=re.compile('\\bdata-nav="([^"]+)"')
ATTR_REQUIRE_RE=re.compile('\\bdata-require="([^"]+)"')
SECTION_BLOCK_RE=re.compile('<section\\b([^>]*)>(.*?)</section>',re.IGNORECASE|re.DOTALL)
CLASS_ATTR_RE=re.compile('class="([^"]*)"')
ECHARTS_SOURCES='https://registry.npmmirror.com/echarts/5.4.3/files/dist/echarts.min.js','https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js'
def build_echarts_cdn():A=f'<script src="{ECHARTS_SOURCES[0]}"></script>';B=''.join(f"<script>window.echarts||document.write('<script src=\"{A}\"><\\/script>')</script>"for A in ECHARTS_SOURCES[1:]);return A+B
ECHARTS_CDN=build_echarts_cdn()
def build_nav_links(body):
	B=[]
	for C in SECTION_OPEN_RE.findall(body):
		A=ATTR_ID_RE.search(C);D=ATTR_NAV_RE.search(C)
		if A and D:B.append((A.group(1),D.group(1)))
	if not B:return''
	E=[]
	for(F,(A,G))in enumerate(B):H=' class="active"'if F==0 else'';E.append(f'    <a href="#{A}"{H}>{G}</a>')
	return'\n'.join(E)
def validate_kline_data(body):
	A=KLINE_DATA_RE.search(body)
	if not A:return False
	B=A.group(1).strip()
	try:json.loads(B)
	except ValueError as C:print(f"[render] 警告: K 线数据岛 #{KLINE_DATA_ID} JSON 解析失败，图表将不渲染: {C}",file=sys.stderr)
	return _B
DIMLIST_OPEN_RE=re.compile('<div\\s+[^>]*\\bid=["\\\']dimlist["\\\'][^>]*>',re.IGNORECASE)
def resolve_panel_css_file(explicit):
	A=explicit
	if A is not _A and A.is_file():return A
	return PANEL_CSS if PANEL_CSS.is_file()else _A
def strip_kline_dimlist_placeholders(body):
	H='</div>';A=body
	if not KLINE_DATA_RE.search(A):return A
	I=DIMLIST_OPEN_RE.search(A)
	if not I:return A
	F=I.end();D=1;C=F;E=_A
	while C<len(A)and D>0:
		G=A.lower().find('<div',C);B=A.lower().find(H,C)
		if B==-1:return A
		if G!=-1 and G<B:D+=1;C=G+4;continue
		D-=1
		if D==0:E=B+len(H);J=A[F:B].strip();break
		C=B+len(H)
	if E is _A:return A
	if not J or J.startswith('<!--'):return A
	print('[render] 警告: K线 #dimlist 含手写卡片，已清空（维度由 kline-data.dims + runtime 渲染）',file=sys.stderr);return A[:F]+A[B:E]+A[E:]
def validate_required_components(body):
	A=[]
	for(C,G)in SECTION_BLOCK_RE.findall(body):
		D=ATTR_REQUIRE_RE.search(C)
		if not D:continue
		E=ATTR_ID_RE.search(C);H=E.group(1)if E else'?';F=set()
		for I in CLASS_ATTR_RE.findall(G):F.update(I.split())
		for B in(A.strip()for A in D.group(1).split(',')):
			if B and B not in F:A.append(f"{H} → .{B}")
	if A:print(f"[render] 警告: section 缺少 data-require 声明的必含组件（模型重写时可能删/挪了）: {A}",file=sys.stderr)
KLINE_OPEN_RE=re.compile('<script\\b[^>]*\\bid="kline-data"[^>]*>',re.IGNORECASE)
def escape_kline_data_island(body):
	A=body;E=KLINE_OPEN_RE.search(A)
	if not E:return A
	B=E.end();F=re.search('<script\\b',A[B:],re.IGNORECASE);G=B+F.start()if F else len(A);C=A[B:G];D=[A.start()for A in re.finditer('</script',C,re.IGNORECASE)]
	if len(D)<=1:return A
	H=D[-1];I=re.sub(_D,_E,C[:H],flags=re.IGNORECASE);print(f"[render] 已转义 K 线数据岛正文中的 </script> {len(D)-1} 处（否则图表会静默失效）",flush=_B);return A[:B]+I+C[H:]+A[G:]
BODY_RISK_PATTERNS=(re.compile('<script\\b(?![^>]*\\bid="kline-data")',re.IGNORECASE),'<script>（K 线数据岛除外）'),(re.compile('\\son[a-z]+\\s*=\\s*[\\"\']',re.IGNORECASE),'on* 内联事件属性'),(re.compile('javascript:',re.IGNORECASE),'javascript: 协议')
def scan_body_risk(body):
	A=[B for(A,B)in BODY_RISK_PATTERNS if A.search(body)]
	if A:print(f"[render] 警告: body 含可执行片段 {A}；引用外部原文前应把 < > & 转成 HTML 实体",file=sys.stderr)
def build_head_extra(body):
	if KLINE_DATA_RE.search(body):
		A=KLINE_RUNTIME_PATH.read_text(encoding=_C)if KLINE_RUNTIME_PATH.is_file()else''
		if not A:print(f"[render] 警告: kline-runtime.js 缺失: {KLINE_RUNTIME_PATH}",file=sys.stderr);return ECHARTS_CDN
		B=re.sub(_D,_E,A,flags=re.IGNORECASE);return ECHARTS_CDN+'\n<script>\n'+B+'\n</script>'
	return ECHARTS_CDN if'echarts'in body.lower()else''
def load_cdn_map():
	if not CDN_MAP_PATH.is_file():print(f"[render] 警告: avatar-cdn.json 缺失，跳过头像 CDN 重写: {CDN_MAP_PATH}",file=sys.stderr);return{}
	try:A=json.loads(CDN_MAP_PATH.read_text(encoding=_C))
	except(OSError,ValueError)as B:print(f"[render] 警告: avatar-cdn.json 解析失败，跳过头像 CDN 重写: {B}",file=sys.stderr);return{}
	if not isinstance(A,dict):print('[render] 警告: avatar-cdn.json 不是 roleId → URL 的对象，跳过头像 CDN 重写',file=sys.stderr);return{}
	return{str(B):str(A)for(B,A)in A.items()if isinstance(A,str)and A.strip()}
def rewrite_avatars_to_cdn(html,cdn_map):
	A=set();B=0;C=0
	def D(match):
		E=match;nonlocal B,C;D=E.group(1);F=cdn_map.get(D)
		if F:B+=1;return E.group(0).replace(f"avatars/{D}.png",F)
		A.add(D);C+=1;return''
	E=AVATAR_IMG_RE.sub(D,html);print(f"[render] 头像 CDN 重写 {B} 处，删除未配置头像 {C} 处",flush=_B)
	if A:print(f"[render] 警告: 以下头像 id 未在 avatar-cdn.json 配置，已移除对应 <img>: {sorted(A)}",file=sys.stderr)
	return E
BRAND='腾讯自选股'
DISCLAIMER_VIEW_TEAM='报告观点基于多专家视角交叉分析，历史与当前数据不代表未来表现，结论可能在不同市场环境下失效。'
DISCLAIMER_VIEW_SOLO='报告为单一专家视角分析，历史与当前数据不代表未来表现，结论可能在不同市场环境下失效。'
def load_panel_css(panel_css_file):
	A=panel_css_file
	if A is _A:return''
	if not A.is_file():print(f"[render] 警告: panel CSS 文件不存在，跳过注入: {A}",file=sys.stderr);return''
	B=A.read_text(encoding=_C).strip()
	if not B:return''
	return f"<style>\n{B}\n</style>"
def resolve_panel_css_arg(raw):
	B=raw.strip()if isinstance(raw,str)else''
	if not B:return
	A=Path(B).resolve()
	if A.suffix.lower()!='.css':print(f"[render] 警告: --panel-css 只接受 .css 文件，已忽略: {A}",file=sys.stderr);return
	try:A.relative_to(PLUGIN_ROOT)
	except ValueError:print(f"[render] 警告: --panel-css 超出专家包目录，已忽略: {A}",file=sys.stderr);return
	return A
def render(body_file,output_html,title,date,team,solo,disclaimer=_A,panel_css_file=_A):
	O='{{DATE}}';N='{{BODY}}';M='{{TITLE}}';H=panel_css_file;D=body_file;B=output_html
	if not SHELL_PATH.is_file():print(f"[render] shell.html 缺失: {SHELL_PATH}",file=sys.stderr);raise SystemExit(2)
	if not D.is_file():print(f"[render] body 文件不存在: {D}",file=sys.stderr);raise SystemExit(2)
	I=SHELL_PATH.read_text(encoding=_C);A=D.read_text(encoding=_C);A=strip_kline_dimlist_placeholders(A);A=escape_kline_data_island(A);scan_body_risk(A)
	for J in(M,N,O):
		if J not in I:print(f"[render] shell.html 缺少占位符 {J}",file=sys.stderr);raise SystemExit(3)
	E=build_nav_links(A);validate_required_components(A);K=validate_kline_data(A);L=build_head_extra(A);C=resolve_panel_css_file(H)
	if C is not _A and H is _A:print(f"[render] 自动注入 panel CSS → {C}",flush=_B)
	elif K and C is _A:print(f"[render] 警告: 检测到 K 线数据岛但 panel CSS 缺失 ({PANEL_CSS})，维度卡片布局可能异常",file=sys.stderr)
	P=load_panel_css(C);Q=E.count('<a ')if E else 0
	if K:F='K线数据岛(注入运行时)'
	elif L:F='注入'
	else:F='未用'
	print(f"[render] nav 标签 {Q} 个（data-nav 自动生成）；ECharts {F}",flush=_B);G=I.replace(M,html_escape(title)).replace('{{NAV_LINKS}}',E).replace('{{HEAD_EXTRA}}',L).replace('{{PANEL_CSS}}',P).replace(O,html_escape(date)).replace('{{TEAM}}',html_escape(team)).replace('{{DISCLAIMER_VIEW}}',disclaimer or(DISCLAIMER_VIEW_SOLO if solo else DISCLAIMER_VIEW_TEAM)).replace(N,A);G=rewrite_avatars_to_cdn(G,load_cdn_map());B.parent.mkdir(parents=_B,exist_ok=_B);B.write_text(G,encoding=_C);R=B.stat().st_size//1024;print(f"[render] 已合成 → {B} ({R} KB)",flush=_B)
def html_escape(value):return html.escape(str(value),quote=_B)
def footer_sign(team):A=[A.strip()for A in str(team).split('·')];return' · '.join([BRAND,*[A for A in A if A and A!=BRAND]])
def _task_dir_from_path(path):
	A=path.expanduser().resolve()
	if A.suffix or A.is_file():A=A.parent
	B=A.parts
	try:C=B.index('deliverables')
	except ValueError:return str(A)
	if len(B)>=C+3:
		D=Path(*B[:C+3])
		try:E=A.relative_to(D)
		except ValueError:return str(D)
		if E.parts:return str(A)
		return str(D)
	if len(B)>=C+2:return str(Path(*B[:C+2]))
	return str(Path(*B[:C+1]))
def report_complete(anchor_path):
	E='WESTOCK_TASK_ID';D='WESTOCK_TASK_DIR'
	if not INIT_TASK.is_file():return
	A=os.environ.copy();B=A.get(D)or A.get('WESTOCK_SESSION_KEY')
	if not B:B=_task_dir_from_path(anchor_path);A[D]=B
	if not A.get(E):
		F=Path(B)/'.westock-task-id'
		try:
			C=F.read_text(encoding=_C).strip()
			if C:A[E]=C
		except OSError:pass
	try:subprocess.run([sys.executable,str(INIT_TASK),'ensure-complete'],check=False,timeout=8,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=A)
	except Exception:pass
def main():
	E='store_true';A=argparse.ArgumentParser(description='研判面板 body → 完整 HTML');A.add_argument('body_file',help='agent 写的 body 片段路径');A.add_argument('output_html',help='最终 HTML 输出路径');A.add_argument('--title',required=_B,help='HTML <title> 标签内容');A.add_argument('--date',default=_A,help='报告日期 YYYY-MM-DD，默认今天');A.add_argument('--team',default='产业洞见官',help='页脚署名的专家名（品牌前缀由脚本自动加，不要重复传）');A.add_argument('--solo',action=E,help='单专家报告：风险提示用单一视角文案（默认团队多专家文案）');A.add_argument('--disclaimer',default=_A,help='自定义风险提示「观点来源」那条文案（per-role 覆盖，优先于 --solo 默认）');A.add_argument('--panel-css',default=_A,help='按专家注入的固定组件 CSS 文件（hold-bar/主题进度/杠杆卡等），缺省走 shell 基类无注入');A.add_argument('--keep-body',action=E,help='保留 body 片段文件（默认渲染完即删）');B=A.parse_args();C=Path(B.body_file).resolve();D=Path(B.output_html).resolve();F=B.date or datetime.date.today().isoformat();G=footer_sign(B.team);H=(B.disclaimer or'').strip()or _A;I=resolve_panel_css_arg(B.panel_css);render(C,D,B.title,F,G,B.solo,H,I);report_complete(D)
	if not B.keep_body:
		if not C.name.endswith('.body.html'):print(f"[render] 跳过清理：{C.name} 不是 *.body.html，按用户文件保留",file=sys.stderr);return
		try:C.unlink();print(f"[render] 已清理 body 片段: {C.name}",flush=_B)
		except OSError as J:print(f"[render] 删除 body 片段失败（忽略）: {J}",file=sys.stderr)
if __name__=='__main__':main()