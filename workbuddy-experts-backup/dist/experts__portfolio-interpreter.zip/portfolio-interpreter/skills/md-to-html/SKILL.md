---
name: md-to-html
description: 把投资组合解读官的 HTML body 片段渲染成腾讯自选股浅色风单文件 HTML（CSS 内联、品牌头 + 风险提示页脚）。写完 body 片段到 panel.body.html 后，调用 scripts/render.py 套壳（加 --solo 与 --panel-css）。
---

# md-to-html

**作用**：把你写好的 HTML body 片段套进 `shell.html`，输出最终单文件 HTML（含完整 CSS + 腾讯自选股品牌头 + 风险提示页脚）。

**何时调用**：用户已粘贴持仓并完成正式解读后。无持仓只回填写模板时**不要**调用本 skill。

---

## 工作流

1. **读模板**：`skills/portfolio-interpretation-framework/references/ref-visual-shell.md` + 同目录 `shell-template.html`，按 🔴 标记逐项替换
2. **写 body 片段**到 `<OUT>/panel.body.html`：每个模块 `<section>` 带 `id` + `data-nav`；**不要**写 `<!DOCTYPE>` / `<html>` / `<head>` / `<style>` / `<nav>` / `<footer>` / `<body>`
3. **调用 `render.py` 套壳（必做）**
4. **交付**：把 `render.py` 打印的 HTML 完整路径告诉用户；md 写在对话正文

**标准渲染命令**（整条写成一行）：

```bash
python3 skills/md-to-html/scripts/render.py "<OUT>/panel.body.html" "<OUT>/<主题>-研判面板.html" --title="<主题> · 腾讯自选股 · 投资组合解读官" --date=YYYY-MM-DD --solo --team="投资组合解读官" --panel-css=skills/portfolio-interpretation-framework/references/panel.css --keep-body
```

> `--solo` 用单专家口径的风险提示；`--panel-css` 缺省会导致版式塌陷。Windows 按 `python3` → `python` → `py -3` 重试。
