# 投资组合诊断官

WorkBuddy Agent 型专家包：分析框架 + Role + HTML 图文面板。

- 无持仓：只返回填写模板，不渲染 HTML
- 不能读取用户账户
- 数据：行情 / ETF 穿透**优先**走 **westock-mcp**（`data_quote` / `data_etf` 等）。已在 `plugin.json` 声明 `dependencies.connectors: ["westock-mcp"]`。连接器取不到时可用其他来源补充并标注；都取不到时写「暂无可靠数据」，不编造穿透或相关性
- 输出：对话 Markdown；有持仓时再用 `render.py` 套壳 HTML（品牌头 + 风险提示页脚），落盘到 `{用户当前工作空间根目录}/deliverables/portfolio-interpreter/<YYYY-MM-DD>/`

头像 `avatars/expert.png` 为占位图（512×512）。

`bin/init_task.py`：任务初始化与收尾。

## 使用数据说明

本插件会在任务启动与报告交付成功时，采集**匿名任务级使用数据**（用于渠道数据看板统计使用情况）：

- **采集内容**：随机生成的设备标识 `dev_id`（首次运行本地生成的 UUID）、事件时间戳、事件类型（start / complete）、任务耗时等常量字段。
  上报报文里这个字段叫 `fwzq_openid`，是沿用既有数据看板的 schema 字段名，**装的是上面那个随机 `dev_id`，与微信账号 / OpenID 无关**。
- **不采集**：任何个人身份信息、股票查询内容、对话内容、账户信息。
- **上报方式**：由 `bin/init_task.py` 通过 HTTPS 上报（调用方用该文件绝对路径，解释器按 `python3` → `python` → `py -3` 重试），全程 fail-safe。若包内有 `render.py`，渲染成功时会自动 `ensure-complete`（按产物目录认领；找不到匹配 start 时不补造）。排障可设 `WESTOCK_TELEMETRY_DEBUG=1`。
- **设备口径**：`dev_id` 与腾讯自选股其它专家包共用同一份本地文件，保证同一台设备只计一个人；任务标记按「专家 + 产物目录」隔离。
- **任务隔离**：任务键为本轮产物目录 `deliverables/portfolio-interpreter/<YYYY-MM-DD>`（同日并发请再加唯一子目录）；每次 `start` 生成唯一 `task_id` 并写入该目录 `.westock-task-id`，`complete` 只认领对应标记。目录下多个 pending 且未指定 id 时不认领。调用方通过 `WESTOCK_TASK_DIR`（兼容 `WESTOCK_SESSION_KEY`）传入产物目录。
- **关闭方式**：设环境变量 `WESTOCK_TELEMETRY=0`（或 `false` / `off` / `no`）即可整体关停。推荐用环境变量而不是删除 `bin/init_task.py`。
- **自检**：`python3 bin/init_task.py dev-id` 打印本机 `dev_id`（Windows 换 `python` 或 `py -3`）。关停状态下该命令只提示「遥测已关停」，**不会生成 dev_id 文件**。
