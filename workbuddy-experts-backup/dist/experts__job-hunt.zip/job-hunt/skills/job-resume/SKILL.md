---
name: job-resume
description: >
  Resume tailoring. Rewrites the user's resume around a target JD, highlighting
  relevant strengths and producing a standalone tailored version. Called by the job-hunt agent.
version: "1.0.0"
tags:
  - resume
  - career
---

# Job Resume — Resume Tailoring

Rewrites the user's resume to fit a target JD, emphasizing relevant strengths without fabricating experience.

## Input

To tailor a resume, you need:
- The user's original resume (file or pasted text)
- Target job title and company
- Full JD text (from search results or user provided)
- Output directory for the tailored file

## Tailoring Principles (Mandatory)

- **Never fabricate** — only reorganize, reword, and emphasize what's already in the resume
- **Never drop essentials**: education, contact info, and other basics must be preserved
- **Align keywords**: match the resume's skill wording to the JD's terminology (e.g. if the JD says "machine learning", spell out "ML")
- **Quantify first**: keep and highlight results backed by numbers
- **ATS-friendly**: use standard section headers (Experience, Education, Skills, etc.)

## Tailoring Strategy

### Analysis

Extract the JD's core requirements:
- Required / must-have skills
- Preferred / nice-to-have skills
- Years of experience required
- Industry or domain preferences

Cross-reference against the resume:
- Exact skill matches → surface to the top
- Related but imprecise matches → adjust wording to align
- Missing requirements → don't invent, but you may add the relevant area under Skills

### Rewrite

| Section | Strategy |
|---------|----------|
| Summary/Objective | Rewrite to speak directly to the role's core requirements |
| Experience | Reorder bullets to put the most relevant first; reword to align with JD keywords |
| Skills | Re-sort by JD relevance, required skills first |
| Projects | Feature the most relevant projects |
| Education | Keep content as-is; place the section per **Education placement** below |

### Output Format

**The output format must match the user's original resume format:**

| Original | Output | How |
|----------|--------|-----|
| `.pdf` | `.pdf` | Re-typeset to PDF (reportlab / weasyprint) with a US Letter layout |
| `.docx` | `.docx` | Edit from the original (unpack → modify XML → repack), preserving the original layout and styling |
| `.md` / `.txt` / pasted text | `.docx` | Generate a professionally typeset Word doc with docx-js |

File naming: `resume_{company_slug}_{title_slug}.docx` (or `.pdf`)

## Resume Content Structure

### Default section order

Section structure (identical across all output formats):

```
[Your Name]
[Contact Info]

Professional Summary
  [2-3 sentence summary tailored to the target role]

Technical Skills
  [skills list sorted by JD relevance]

Professional Experience
  [Job Title] | [Company] | [Date]
  - [bullet points optimized for the target role]

Projects
  [Project Name]
  - [highlight tech and results relevant to the JD]

Education
  [Degree] | [University] | [Date]
  - [relevant coursework / honors]
```

### Education placement

| Candidate | Education section |
|-----------|-------------------|
| Entry-level / new grad / limited work experience | After Summary or Skills, **before** Professional Experience |
| Experienced | **Last section** |

### Resume Length (by seniority)

Match the page count to the candidate's experience level:
- Entry-level / new grad / ≤ 5 years of experience → **1 page**
- More senior profiles → up to 2 pages

When content overflows the target length, trim the least-relevant lines (oldest or weakest bullets) rather than spilling onto another page.

### docx/pdf Notes

- If the original resume is docx, **copy it to the output directory first, then edit the copy** (preserving layout, fonts, spacing); never modify the user's original file
- When generating docx from scratch, use docx-js with US Letter page size, 1-inch margins, and Arial font
- When outputting PDF, use reportlab / weasyprint with a US Letter layout

### Layout Self-check (Mandatory)

After generating the file, render it and verify the layout; fix and regenerate if any check fails:

- **No overlapping elements**: in particular, the header name must sit on its own line above the contact line — they must never overlap
- **No orphan page**: page count isn't fixed to one, but no page may hold only a line or two of content. If the last page has just a stray line, tighten spacing/margins or trim the least-relevant line so it flows back onto the previous page
- **No awkward layout**: no large blank gaps mid-document, and a section heading shouldn't be stranded alone at the bottom of a page — keep it with at least the opening lines of its section

## Interaction

After generating, show the tailored resume and a match analysis:

```markdown
## 📄 Tailored Resume: {job_title} @ {company}

**Match analysis:**
- ✅ Matched skills: Python, TensorFlow, PyTorch
- ⚠️ Required by JD but missing: Kubernetes
- 💡 Highlights: 2 years of ML project experience
```

**Display rules:**

- **`present_files`** when resumes are ready — batch all files in one call
- **Prompt next step** (plain text):

```
Your resumes are ready — click the files above to preview. Once you've reviewed them:
- Reply "confirm" → I'll generate the final application checklist
- To revise, just tell me which one and what to change (e.g. "make the Unity one emphasize distributed systems")
```

**Revisions:** apply change → `present_files` → brief summary → same prompt. Never end a revision turn without re-presenting the file.
