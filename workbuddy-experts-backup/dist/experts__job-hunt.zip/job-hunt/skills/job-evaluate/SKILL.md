---
name: job-evaluate
description: >
  Evaluate validated jobs against the candidate profile. Mark hard mismatches
  ineligible with reason; score eligible jobs. Write results to evaluated_results.md.
  Run after job-validation.
version: "3.3.0"
tags:
  - job-evaluation
  - matching
---

# Job Evaluate

## Goal

Produce `evaluated_results.md` — one markdown table with every validated job.

Each row captures:
- **Should I apply?** — Status (`eligible` / `ineligible`); if ineligible, a short **Reason**
- **How good a fit?** — Match (score 0–99 when eligible)
- **What to highlight?** — Requirements (matched skills and gaps, eligible only)

## When to Run

After `validate_jobs.py` → `validated_results.json` exists. Before job selection.

**Inputs:** `validated_results.json` (active/unknown jobs only) + `candidate_profile.json`

**Output:** `evaluated_results.md`

## Workflow

For each batch (8–10 jobs):

1. **Read batch** — load the next slice from `validated_results.json` (filter `active` / `unknown` only)
2. **Hard gates** — any blocker → `ineligible` with **Reason**; skip Match
3. **Score** — eligible jobs only → **Match** + **Requirements**
4. **Append** — write rows to `evaluated_results.md`

## Evaluate rules

Per job: compare JD against `candidate_profile.json` → set **Status**, **Reason**, **Match**, **Requirements** → write row.

### Inputs

**Evaluate** (read these to judge):
- `candidate_profile.json`
- From each validated job — role: `title`, `company`, `location`
- From each validated job — JD: `description`, `qualifications`, `responsibilities`

**Append** (write to table only; do not use for eligibility or scoring):
- `apply_url`, salary, source, and other listing metadata
- Apply column: `[Apply]({apply_url})` — fetch the URL from `validated_results.json` per job; never hand-type, shorten, or fabricate

**Apply URL rules (mandatory):**
- Never slice or truncate `apply_url` (no `[:N]`, no ellipsis)
- Do not print `apply_url` in Bash preview scripts — evaluation does not need URLs in the terminal
- Before writing each row's Apply cell, fetch the full URL from JSON:

```bash
python3 -c "
import json
jobs = json.load(open('validated_results.json'))['jobs']
j = next(x for x in jobs if x['title']=='''TITLE''' and x['company']=='''COMPANY''')
print(j['apply_url'])
"
```

Replace `TITLE` / `COMPANY` with the exact strings for that row.

### Evaluate

**Order:** hard gates first → if none hit, mark `eligible` and score.

| Field | `eligible` | `ineligible` |
|-------|------------|--------------|
| **Status** | `eligible` | `ineligible` |
| **Reason** | empty | short phrase (e.g. `3+ yrs required`, `Seniority mismatch`, `No sponsorship`) |
| **Match** | 0–99 (never 100) | blank |
| **Requirements** | matched skills and gaps | blank |

#### Hard gates

Check JD (`title`, `description`, `qualifications`, `responsibilities`) against `candidate_profile.json`. **Any gate → `ineligible`; do not assign Match.**

**All candidates:** citizenship / work authorization mismatch · clearance required and not held · no sponsorship when `needs_sponsorship: true` · JD explicitly **new-grad / entry only** when profile is mid/senior.

**Entry / new grad** (`experience_level: entry` or `experience_years ≤ 1`) — any row hit → **`ineligible`**:

| JD signal | Status | Reason |
|-----------|--------|--------|
| Minimum **≥2 years** experience (2+, 2–3, "two years", etc.) | `ineligible` | `2+ yrs required` |
| Minimum **≥3 years** | `ineligible` | `3+ yrs required` |
| Title: Senior, Sr, Staff, Principal, Lead, III/IV (not "Team Lead" as sole signal) | `ineligible` | `Seniority mismatch` |
| JD says mid-level / experienced hire with no entry path | `ineligible` | `Seniority mismatch` |

**Do not** mark entry candidates eligible on "3+ years preferred" alone — **minimum / required** language triggers the gate. "Preferred" or "nice to have" does not.

**Mid** (`experience_level: mid`): ineligible if JD requires **≥8 years** or Staff/Principal-only seniority.

**Senior** (`experience_level: senior`): ineligible if JD is explicitly entry/new-grad only.

#### Scoring (eligible only)

- Skill gaps → still `eligible`, lower **Match**
- **Unsure on skills** → `eligible`, conservative Match
- **Unsure on years or seniority** (entry profile) → `ineligible`, not eligible

**Match** weights: Skills 40% · Experience 25% · Keyword 20% · Location 15%

## Done when

- `evaluated_results.md` exists on disk
- Every active/unknown validated job appears in the table
- Spot-check: pick 2 rows at random — each Apply URL must match `validated_results.json` `apply_url` byte-for-byte

## Results table format

```markdown
| # | Title | Company | Location | Salary | Match | Status | Reason | Source | Apply | Requirements |
|---|-------|---------|----------|--------|-------|--------|--------|--------|-------|--------------|
| 1 | AI Engineer | Google | SF, CA | $150K | 88 | eligible | | LinkedIn | [Apply](url) | Python, PyTorch; gap: K8s |
| 2 | Sr ML Engineer | Meta | SF, CA | $200K | | ineligible | Seniority mismatch | LinkedIn | [Apply](url) | |
| 3 | ML Engineer | Stripe | Remote | $130K | | ineligible | 3+ yrs required | LinkedIn | [Apply](url) | |
| 4 | ML Engineer I | Stripe | Remote | $130K | 72 | eligible | | Greenhouse | [Apply](url) | Python, SQL; gap: Spark |
```
