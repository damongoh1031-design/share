---
name: job-search
description: >
  Job search: run search_jobs.py, merge multiple queries, handle failures.
  Use after collecting candidate profile, before validation.
version: "4.1.0"
tags:
  - job-search
  - api
---

# Job Search

Aggregates job listings via `search_jobs.py`. Never fabricate `search_results.json` — output must come from running the script or an honest WebSearch fallback (see [When things go wrong](#when-things-go-wrong)).

## Contract

- **Output**: `search_results.json` from `search_jobs.py`
- **Never** hand-write or fabricate results
- **Next step**: job-validation (`validate_jobs.py`)

## Flow

1. Run the closest-match query from the user's target + resume
2. Usually run a **second query** — alternate title, same job function — and **merge**
3. After merge, check whether the pool still looks narrow (see [Decision guide](#decision-guide))
   - Still narrow, or the last merge added meaningful new jobs → optional **third query** + merge
   - Gains tapering off → finalize `search_results.json`
4. Pass output to validation

**Quick scan only** — if the user explicitly wants a fast look, one search is fine.

## Decision guide

**Principles**

- **One search is often not enough** — different titles surface different postings; a second complementary query is worthwhile in most runs
- **Specific first, broader later** — start with the target title; widen with alternate titles for the **same function**, not a different job family
- **Trust single-search counts** — each run's `metadata.total_results` is already deduped across providers; use it to judge that query, not overall coverage
- **Judge coverage after merge** — "enough" means the merged pool, not any single file
- **Third search is optional** — consider it when merge still looks thin; skip it when another merge would mostly duplicate existing jobs (`dedup_removed` small)
- **Follow user intent** — "comprehensive" / "deep search" → lean toward a third variant; "quick look" → one search is fine

**After each merge, ask**

- Does merged `total_results` still feel sparse for this user and location?
- Are the queries still covering a narrow title axis (only one angle)?
- Would another query likely add new jobs, or mostly overlap?

Avoid word-order shuffles (`"AI Agentic Engineer"` vs `"Agentic AI Engineer"`) and jumping to unrelated functions (SWE → DevOps) unless the user asked.

## Examples

### Typical — two queries + merge

User: AI/ML roles, 3 years NLP, SF. One title alone often misses postings listed under another.

```bash
python3 scripts/search_jobs.py \
  --keyword "NLP Engineer" --location "San Francisco, CA" \
  --country us --date-posted month --output search_results_1.json

python3 scripts/search_jobs.py \
  --keyword "Machine Learning Engineer" --location "San Francisco, CA" \
  --country us --date-posted month --output search_results_2.json

python3 scripts/search_jobs.py \
  --merge search_results_1.json search_results_2.json \
  --output search_results.json
```

→ Check merged `total_results` and `dedup_removed`; proceed to validation.

### Optional third query

After two searches merge, the pool still looks thin **or** `dedup_removed` on the last merge was large (lots of new jobs from query 2). Try one more same-function title — e.g. `"AI Engineer"` — merge into `search_results.json`, then stop if the next merge barely adds rows.

### Quick scan — one search

User: "Just a quick look at what's out there." Run one query; if `total_results` is reasonable, skip extra searches.

### New grad backend

Start `"Junior Backend Engineer"`; if thin, add `"Software Engineer"` (same function, broader title) and merge.

## Commands

**Search**

```bash
python3 scripts/search_jobs.py \
  --keyword "<keyword>" \
  --location "<location>" \
  --country <country_code> \
  --date-posted <range> \
  --max-results <n> \
  --providers <provider_list> \
  --output <output_json_path>
```

**Merge** — local only, no backend call; works even if a later search fails

```bash
python3 scripts/search_jobs.py \
  --merge search_results_1.json search_results_2.json \
  --output search_results.json
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--keyword` | Yes (search) | Include seniority when relevant: `"Junior Backend Engineer"` |
| `--location` | No | e.g. `"San Francisco, CA"`, `"Remote"` |
| `--country` | No | Default `us`. Infer from location (London → `gb`, Toronto → `ca`) |
| `--date-posted` | No | `today` / `3days` / `week` / `month`. Omit to skip |
| `--max-results` | No | Per provider. Default `20`, max `40` |
| `--providers` | No | Default `serpapi,jsearch` |
| `--output` | Yes | Output JSON path |
| `--merge` | No | Merge 2+ result files |

Recent jobs → `--date-posted today` or `3days`. Seniority → in `--keyword`, not a separate param.

## When things go wrong

**Backend search unavailable** (exit 1, stderr contains **search mode is unavailable**): tell the user, then **WebSearch fallback** — label source honestly, same schema, still run validation. Partial search JSON files can still be **`--merge`d** locally.

**Script exits with code ≠ 0** (timeout, connection, backend error): fall back to WebSearch.

**Partial provider failure** (exit 0, entries in `metadata.sources_failed`): proceed with available jobs; read **`metadata.source_errors`** (e.g. jsearch `429` = rate limited — do not retry that provider immediately).

**Very few jobs after exhausting queries**: relax `--date-posted`, try another alternate title, or WebSearch if the backend path is exhausted.

## Reference

**Key output fields**

| Field | Meaning |
|-------|---------|
| `metadata.total_results` | Job count after dedup (per search or after merge) |
| `metadata.dedup_removed` | Merge only — how many duplicates dropped; small → queries overlapping |
| `metadata.sources_failed` / `source_errors` | Which providers failed and why |

**Data sources**

| Provider | Strengths |
|----------|-----------|
| serpapi | Broad coverage, structured highlights, multiple apply links |
| jsearch | Recent postings, benefits info |

Each job includes `apply_url`, `apply_alternates`, `description`, `posted_date`, and related fields — see a run's JSON for the full schema.
