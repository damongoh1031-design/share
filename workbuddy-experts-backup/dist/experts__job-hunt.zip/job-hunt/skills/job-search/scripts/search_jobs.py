#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Job search via agenttool backend, with merge/dedup support.

Search mode:
    python3 search_jobs.py \
        --keyword "AI Engineer" \
        --location "New York" \
        --output search_results_1.json

Merge mode:
    python3 search_jobs.py --merge results_1.json results_2.json --output search_results.json
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    import requests
except ImportError:
    print("ERROR: 'requests' package not installed. Run: pip install requests", file=sys.stderr)
    sys.exit(1)

try:
    from discover_proxy import get_service_proxy_url
except ImportError:
    get_service_proxy_url = None  # type: ignore[misc, assignment]

PROXY_TIMEOUT = 120
SEARCH_PATH = "/agenttool/v1/jobsearch/search"

# Query params to strip from apply URLs (ads / analytics tracking)
_TRACKING_QUERY_EXACT = frozenset({
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "utm_id", "utm_source_platform", "utm_reader", "utm_name",
    "fbclid", "gclid", "msclkid", "mc_cid", "mc_eid",
})


def clean_apply_url(url):
    """Remove ad/tracking query params; keep functional params and path."""
    if not url or not isinstance(url, str):
        return url or ""
    url = url.strip()
    parsed = urlparse(url)
    if not parsed.query:
        return url
    kept = [
        (k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True)
        if k.lower() not in _TRACKING_QUERY_EXACT and not k.lower().startswith("utm_")
    ]
    return urlunparse(parsed._replace(query=urlencode(kept), fragment=""))


def _search_unavailable_error(reason: str):
    print(
        f"ERROR: {reason}\n"
        "  search_jobs.py search mode is unavailable.\n"
        "  → Agent should use WebSearch fallback.",
        file=sys.stderr,
    )


def get_proxy_url():
    if get_service_proxy_url is None:
        _search_unavailable_error(
            "discover_proxy module not found (expected alongside search_jobs.py in scripts/)."
        )
        return None
    return get_service_proxy_url()


def build_search_url(proxy_url: str) -> str:
    return f"{proxy_url.rstrip('/')}{SEARCH_PATH}"


def _proxy_discover_error():
    _search_unavailable_error(
        "unable to discover CODEBUDDY_SERVICE_PROXY_URL "
        "(sidecar not running or agent-cli < 2.136)."
    )


def map_job(raw, source):
    """Map backend JobResult to client flat format."""
    highlights = raw.get("highlights") or {}
    apply_links = raw.get("apply") or []

    apply_url = ""
    apply_alternates = []
    if apply_links:
        apply_url = clean_apply_url(apply_links[0].get("url", ""))
        for link in apply_links[1:]:
            apply_alternates.append({
                "title": link.get("title", ""),
                "link": clean_apply_url(link.get("url", "")),
            })

    return {
        "title": raw.get("title", ""),
        "company": raw.get("company", ""),
        "location": raw.get("location", ""),
        "salary": raw.get("salary", ""),
        "description": raw.get("description", ""),
        "qualifications": highlights.get("qualifications") or [],
        "responsibilities": highlights.get("responsibilities") or [],
        "benefits": highlights.get("benefits") or [],
        "apply_url": apply_url,
        "apply_alternates": apply_alternates,
        "posted_date": raw.get("posted_date", ""),
        "source": source,
        "publisher": raw.get("publisher", ""),
        "employment_type": raw.get("employment_type", ""),
    }


def search_jobs(keyword, location, country, date_posted, max_results, providers):
    proxy_url = get_proxy_url()
    if not proxy_url:
        _proxy_discover_error()
        sys.exit(1)

    payload = {
        "providers": providers,
        "query": keyword,
    }
    if location:
        payload["location"] = location
    if country:
        payload["country"] = country
    if date_posted:
        payload["date_posted"] = date_posted
    if max_results:
        payload["provider_max_results"] = max_results

    url = build_search_url(proxy_url)
    print(f"Searching: query={keyword!r}, location={location!r}, country={country}", file=sys.stderr)

    try:
        resp = requests.post(
            url,
            json=payload,
            headers={
                "Content-Type": "application/json",
                "X-Service-Id": "agenttool",
            },
            timeout=PROXY_TIMEOUT,
        )
        resp.raise_for_status()
    except requests.exceptions.Timeout:
        print("ERROR: backend request timed out", file=sys.stderr)
        sys.exit(1)
    except requests.exceptions.ConnectionError:
        print("ERROR: cannot connect to sidecar proxy", file=sys.stderr)
        sys.exit(1)
    except requests.exceptions.HTTPError:
        print(f"ERROR: backend returned {resp.status_code}: {resp.text}", file=sys.stderr)
        sys.exit(1)

    try:
        body = resp.json()
    except (json.JSONDecodeError, ValueError):
        print(f"ERROR: invalid JSON response: {resp.text[:200]}", file=sys.stderr)
        sys.exit(1)

    if body.get("success") is False:
        err = body.get("error") or {}
        msg = err.get("message") or err.get("code") or "unknown proxy error"
        print(f"ERROR: sidecar proxy failed: {msg}", file=sys.stderr)
        sys.exit(1)

    if body.get("code", 0) != 0:
        print(f"ERROR: backend error code={body.get('code')}, msg={body.get('msg', '')}", file=sys.stderr)
        sys.exit(1)

    data = body.get("data", {})
    results = data.get("results", {})
    errors = data.get("errors", {})

    jobs = []
    sources_used = []
    for provider, provider_jobs in results.items():
        if provider_jobs:
            sources_used.append(provider)
            for raw_job in provider_jobs:
                jobs.append(map_job(raw_job, provider))

    sources_failed = list(errors.keys()) if errors else []
    source_errors = normalize_source_errors(errors)

    # Dedup across providers within a single search
    jobs = dedup_jobs(jobs)

    print(f"Done: {len(jobs)} jobs from {sources_used}", file=sys.stderr)
    if sources_failed:
        for provider in sources_failed:
            print(f"WARNING: failed source {provider}: {source_errors.get(provider, '')}", file=sys.stderr)

    output = {
        "metadata": {
            "query": keyword,
            "location": location or "",
            "country": country or "us",
            "date_posted": date_posted or "",
            "search_time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "total_results": len(jobs),
            "sources_used": sources_used,
            "sources_failed": sources_failed,
            "source_errors": source_errors,
        },
        "jobs": jobs,
    }
    return output


def normalize_source_errors(errors):
    """Map provider name → error message from backend partial failures."""
    if not errors:
        return {}
    out = {}
    for provider, err in errors.items():
        if err is None:
            continue
        if isinstance(err, str):
            out[provider] = err
        elif isinstance(err, dict):
            out[provider] = err.get("message") or json.dumps(err, ensure_ascii=False)
        else:
            out[provider] = str(err)
    return out


def normalize_key(text):
    """Normalize text for dedup comparison."""
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def dedup_key(job):
    return normalize_key(job.get("company", "")) + "|" + normalize_key(job.get("title", ""))


def sanitize_job_urls(job):
    """Clean tracking params from stored apply links (merge mode / dedup)."""
    job["apply_url"] = clean_apply_url(job.get("apply_url", ""))
    for alt in job.get("apply_alternates") or []:
        alt["link"] = clean_apply_url(alt.get("link", ""))
    return job


def dedup_jobs(jobs):
    """Deduplicate jobs by normalized company+title. Keeps the record with longest description, merges apply links."""
    seen = {}
    for job in jobs:
        key = dedup_key(job)
        if key not in seen:
            seen[key] = job
        else:
            existing = seen[key]
            if len(job.get("description", "")) > len(existing.get("description", "")):
                extra_links = []
                if existing.get("apply_url"):
                    extra_links.append({"title": existing.get("publisher", existing.get("source", "")), "link": existing["apply_url"]})
                extra_links.extend(existing.get("apply_alternates", []))
                job.setdefault("apply_alternates", []).extend(extra_links)
                seen[key] = job
            else:
                extra_links = []
                if job.get("apply_url"):
                    extra_links.append({"title": job.get("publisher", job.get("source", "")), "link": job["apply_url"]})
                extra_links.extend(job.get("apply_alternates", []))
                existing.setdefault("apply_alternates", []).extend(extra_links)
    return [sanitize_job_urls(j) for j in seen.values()]


def merge_jobs(input_files):
    all_jobs = []
    all_sources = set()
    merged_source_errors = {}

    for filepath in input_files:
        try:
            with open(filepath) as f:
                data = json.load(f)
        except (IOError, json.JSONDecodeError) as e:
            print(f"ERROR: cannot read {filepath}: {e}", file=sys.stderr)
            sys.exit(1)

        jobs = data.get("jobs", [])
        all_jobs.extend(jobs)
        meta = data.get("metadata", {})
        for s in meta.get("sources_used", []):
            all_sources.add(s)
        merged_source_errors.update(meta.get("source_errors") or {})

    total_before = len(all_jobs)
    deduped_jobs = dedup_jobs(all_jobs)
    dedup_removed = total_before - len(deduped_jobs)

    print(f"Merged {len(input_files)} files: {total_before} jobs → {len(deduped_jobs)} after dedup ({dedup_removed} removed)", file=sys.stderr)

    output = {
        "metadata": {
            "merge_inputs": input_files,
            "total_before_dedup": total_before,
            "total_results": len(deduped_jobs),
            "dedup_removed": dedup_removed,
            "sources_used": sorted(all_sources),
            "sources_failed": sorted(merged_source_errors.keys()),
            "source_errors": merged_source_errors,
        },
        "jobs": deduped_jobs,
    }
    return output


def write_output(data, output_path):
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, ensure_ascii=False, indent=2, fp=f)
    print(f"Output: {output_path}", file=sys.stderr)
    print(json.dumps(data, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Job search via agenttool backend")
    parser.add_argument("--keyword", help="Job search keywords")
    parser.add_argument("--location", default="", help="Job location")
    parser.add_argument("--country", default="us", help="Country code (default: us)")
    parser.add_argument("--date-posted", default="", help="Date filter: today/3days/week/month")
    parser.add_argument("--max-results", type=int, default=20, help="Max results per provider (default: 20, max: 40)")
    parser.add_argument("--providers", default="serpapi,jsearch", help="Comma-separated providers")
    parser.add_argument("--output", required=True, help="Output JSON file path")
    parser.add_argument("--merge", nargs="+", metavar="FILE", help="Merge mode: input files to merge and dedup")
    args = parser.parse_args()

    if args.merge:
        result = merge_jobs(args.merge)
    else:
        if not args.keyword:
            print("ERROR: --keyword is required in search mode", file=sys.stderr)
            sys.exit(1)
        result = search_jobs(
            keyword=args.keyword,
            location=args.location,
            country=args.country,
            date_posted=args.date_posted,
            max_results=min(args.max_results, 40),
            providers=args.providers,
        )

    write_output(result, args.output)


if __name__ == "__main__":
    main()
