# -*- coding: utf-8 -*-
"""Discover CODEBUDDY_SERVICE_PROXY_URL."""

from __future__ import annotations

import concurrent.futures
import json
import os
import socket
import sys
import urllib.error
import urllib.request
from typing import List, Optional

_PROXY_PATH = "/internal/hooks/services/invoke"
_ENV_KEY = "CODEBUDDY_SERVICE_PROXY_URL"
_GATEWAY_PASSWORD_KEY = "CODEBUDDY_GATEWAY_PASSWORD"
_AUTH_PROBE_PATH = "/api/v1/sessions"
_PROBE_TIMEOUT = 1
_SCAN_TIMEOUT = 0.03
_SCAN_WORKERS = 32

_cached_url: Optional[str] = None


def get_service_proxy_url() -> Optional[str]:
    global _cached_url
    if _cached_url:
        return _cached_url

    url = os.environ.get(_ENV_KEY, "").strip()
    if not url:
        url = _discover()

    if url:
        _cached_url = url
    return url


def _discover() -> Optional[str]:
    cache_file = _cache_path()
    cached_port = _read_cache(cache_file)
    if cached_port and _proxy_probe(cached_port):
        return f"http://127.0.0.1:{cached_port}{_PROXY_PATH}"

    candidates = _scan_for_proxy_ports()
    if not candidates:
        return None

    if len(candidates) == 1:
        port = candidates[0]
        _write_cache(cache_file, port)
        return f"http://127.0.0.1:{port}{_PROXY_PATH}"

    port = _resolve_by_auth(candidates)
    if port:
        _write_cache(cache_file, port)
        return f"http://127.0.0.1:{port}{_PROXY_PATH}"
    return None


def _proxy_probe(port: int) -> bool:
    try:
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}{_PROXY_PATH}",
            data=b"{}",
            method="POST",
            headers={"Content-Type": "application/json", "X-Service-Id": "probe"},
        )
        with urllib.request.urlopen(req, timeout=_PROBE_TIMEOUT) as resp:
            return resp.status == 200 and "json" in resp.headers.get("Content-Type", "")
    except Exception:
        return False


def _resolve_by_auth(candidates: List[int]) -> Optional[int]:
    password = os.environ.get(_GATEWAY_PASSWORD_KEY, "").strip()
    if not password:
        return candidates[0]

    for port in candidates:
        try:
            req = urllib.request.Request(
                f"http://127.0.0.1:{port}{_AUTH_PROBE_PATH}",
                method="GET",
                headers={"Authorization": f"Bearer {password}"},
            )
            with urllib.request.urlopen(req, timeout=_PROBE_TIMEOUT) as resp:
                if resp.status == 200 and "json" in resp.headers.get("Content-Type", ""):
                    return port
        except Exception:
            continue
    return candidates[0]


def _scan_for_proxy_ports() -> List[int]:
    results: List[int] = []

    def _try(port: int) -> Optional[int]:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(_SCAN_TIMEOUT)
                if s.connect_ex(("127.0.0.1", port)) != 0:
                    return None
        except OSError:
            return None
        return port if _proxy_probe(port) else None

    with concurrent.futures.ThreadPoolExecutor(max_workers=_SCAN_WORKERS) as ex:
        futures = [ex.submit(_try, p) for p in range(32768, 65536)]
        for f in concurrent.futures.as_completed(futures):
            result = f.result()
            if result is not None:
                results.append(result)

    return sorted(results)


def _cache_path() -> str:
    return os.path.join(os.getcwd(), ".sidecar_proxy_port")


def _read_cache(path: str) -> Optional[int]:
    try:
        with open(path, "r") as f:
            return int(f.read().strip())
    except (IOError, ValueError):
        return None


def _write_cache(path: str, port: int) -> None:
    try:
        with open(path, "w") as f:
            f.write(str(port))
    except IOError:
        pass


if __name__ == "__main__":
    url = get_service_proxy_url()
    if url:
        print(url)
    else:
        print("ERROR: unable to discover CODEBUDDY_SERVICE_PROXY_URL", file=sys.stderr)
        sys.exit(1)
