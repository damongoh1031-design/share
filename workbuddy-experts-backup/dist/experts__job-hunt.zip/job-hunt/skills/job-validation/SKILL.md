---
name: job-validation
description: >
  Verifies whether job posting links are still active. Detects dead links, expired postings,
  and removed positions. Run after search, before evaluate. Does not assess candidate fit.
version: "3.0.0"
tags:
  - job-validation
  - freshness
---

# Job Validation

Checks whether job posting URLs are still live and accepting applications. Filters out dead links, expired postings, and removed positions before showing results to the user.

## When to Run

Run **after** `search_jobs.py` produces `search_results.json`, **before** `job-evaluate`. Every job the user sees must have been validated. Candidate fit (eligibility, match score) is handled by `job-evaluate`, not here.

## Usage

```bash
# Validate search results (standard flow)
python3 scripts/validate_jobs.py --input search_results.json --output validated_results.json

# Validate a single URL (ad-hoc check)
python3 scripts/validate_jobs.py --url "https://linkedin.com/jobs/view/12345"
```

## Output

Each job gets three fields added:
- `validation_status`: `active` / `expired` / `unknown`
- `validation_tier`: which check determined the result
- `validation_reason`: human-readable explanation

Output file splits jobs into two arrays:
```json
{
  "metadata": {
    "total": 42,
    "active": 35,
    "expired": 5,
    "unknown": 2
  },
  "jobs": [...],           // active + unknown (show to user)
  "expired_jobs": [...]    // filtered out
}
```

## How to Interpret Results

| Status | Show to user? | Action |
|--------|--------------|--------|
| `active` | Yes | Display normally |
| `unknown` | Yes, with caveat | Mark as "⚠️ unverified" — link might still work, advise user to check |
| `expired` | No | Filtered out of `jobs` array, don't show |

## What It Checks (in order)

1. **URL validity** — missing or generic URLs (company homepage, `/careers`, `/jobs`) → expired
2. **Posting age** — `posted_date` exceeds TTL threshold → expired
3. **Network check** — fetches the URL and analyzes:
   - HTTP 404/410 → expired
   - Redirects to generic page → expired
   - Page contains "no longer available" / "position has been filled" etc. → expired
   - Bot challenge / Cloudflare → unknown
   - Page normal, no expiry signals → active
4. **HTTP 403 fallback** — when the primary `apply_url` returns HTTP 403 (common on talent.com and similar aggregators):
   - Try each `apply_alternate` in order
   - First alternate that is `active` or `unknown` (non-403) is promoted to `apply_url`
   - If **every** checked link (primary + alternates) returns HTTP 403 → `expired`, job excluded

LinkedIn URLs are automatically resolved through a guest-accessible endpoint (no login required).

## Important Notes

- **Don't skip validation** — search results contain stale postings (especially 2+ weeks old)
- **Don't fabricate results** — `validated_results.json` must come from actually running the script
- **Partial results are OK** — if some URLs timeout, they're marked `unknown` and still shown to the user
- **Re-validate if needed** — if user asks "is this job still open?" for a specific posting, use single-URL mode

## Performance

- LinkedIn jobs validate fastest (guest endpoint, single request)
- Some sites (Glassdoor, ZipRecruiter) may return `unknown` due to anti-bot measures
