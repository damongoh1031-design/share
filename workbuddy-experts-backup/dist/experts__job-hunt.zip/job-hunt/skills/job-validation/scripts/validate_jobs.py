#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Job posting validation script with tiered verification strategy.

Tier 1: API field filtering (zero network cost)
Tier 2: HTTP HEAD request (detect dead links)
Tier 3: Lightweight HTML fetch + keyword scan + JSON-LD parsing
Tier 4: Not handled here (browser automation, delegated to MCP)

Usage:
    # Validate a single URL
    python3 validate_jobs.py --url "https://example.com/jobs/12345"

    # Validate from search results JSON
    python3 validate_jobs.py --input search_results.json --output validated_results.json

    # Custom TTL threshold (days)
    python3 validate_jobs.py --input search_results.json --ttl 30
"""

import argparse
import json
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from urllib.parse import urlparse

try:
    import requests
except ImportError:
    print("ERROR: 'requests' package not installed. Run: pip install requests", file=sys.stderr)
    sys.exit(1)

DEFAULT_TTL_DAYS = 30
TIMEOUT = 30
# Low concurrency: avoid triggering site rate limits from bursty requests (was 10 → 3)
MAX_WORKERS = 8

# Real Chrome browser User-Agent (mimics a human visit, markedly lowers Tier 2/3 403 rates)
CHROME_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0.0.0 Safari/537.36"
)

# Full browser header set (all required) for Tier 2/3.
# Note: don't set Accept-Encoding manually; let requests handle gzip/deflate decompression.
BROWSER_HEADERS = {
    "User-Agent": CHROME_UA,
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,image/apng,*/*;q=0.8,"
        "application/signed-exchange;v=b3;q=0.7"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "Connection": "keep-alive",
}

EXPIRED_KEYWORDS_EN = [
    "job is no longer available",
    "position is closed",
    "this job has expired",
    "no longer accepting applications",
    "position has been filled",
    "job has been removed",
    "this position is no longer open",
    "this role has been filled",
    "this job is no longer available",
    "sorry, this position has been filled",
    "this listing has expired",
    # --- Actual copy from BuiltIn / Indeed / Monster and similar sites ---
    "this job was removed",           # BuiltIn: "Sorry, this job was removed at 01:25 a.m. ..."
    "was removed at",                 # BuiltIn variant (with timestamp)
    "job posting has been removed",
    "job posting is no longer available",
    "this job is no longer accepting applications",
    "no longer available",            # generic catch-all (Indeed / ZipRecruiter)
    "job has expired",
    "posting has expired",
    "this opportunity is no longer available",
    "applications are closed",
    "we are no longer accepting applications",
    "position is no longer available",
    "role is no longer available",
    "job closed",
    "vacancy is closed",
    "this vacancy has expired",
    "recruitment for this position has ended",
    "job ad has expired",
    "this job ad is no longer active",
]

# Kept for Chinese-language job sites
EXPIRED_KEYWORDS_ZH = [
    "已停止接受申请",
    "已停止招聘",
    "该职位已下线",
    "职位已关闭",
    "招聘已结束",
    "暂停招聘",
    "此职位不再招聘",
    "职位已过期",
]

ALL_EXPIRED_KEYWORDS = EXPIRED_KEYWORDS_EN + EXPIRED_KEYWORDS_ZH

GENERIC_PATH_PATTERNS = [
    r"^/careers/?$",
    r"^/jobs/?$",
    r"^/jobs/search",
    r"^/search",
    r"^/opportunities/?$",
    r"^/en/?$",
    r"^/en/jobs/?$",
    r"^/?$",
]

# Strong signals: only appear on blocked/challenge pages, never on normal job pages
BLOCKED_PAGE_SIGNALS = [
    "authwall",
    "checking your browser",
    "verify you are human",
    "cf-browser-verification",
    "challenge-platform",
    "performance & security by cloudflare",
    "please verify you are a human",
    "press & hold",
    "please wait while we verify",
    "verify you're not a robot",
]


def is_generic_url(url):
    """Check if URL is a generic page (not a specific job posting)."""
    path = urlparse(url).path.rstrip("/") or "/"

    for pattern in GENERIC_PATH_PATTERNS:
        if re.match(pattern, path, re.IGNORECASE):
            return True

    return False


def parse_date(date_str):
    """Parse various date formats to datetime."""
    if not date_str:
        return None
    # Strip trailing timezone abbreviations (e.g. " UTC", " PST")
    date_str = re.sub(r"\s+[A-Z]{2,4}$", "", date_str.strip())
    for fmt in [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%b %d, %Y",          # "Aug 20, 2026"
        "%B %d, %Y",          # "August 20, 2026"
        "%d %b %Y",           # "20 Aug 2026"
        "%d %B %Y",           # "20 August 2026"
    ]:
        try:
            return datetime.strptime(date_str, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def days_since(date_str):
    """Calculate days elapsed since given date string."""
    dt = parse_date(date_str)
    if not dt:
        return None
    now = datetime.now(timezone.utc)
    return (now - dt).days


def parse_relative_days(text):
    """Parse relative time like '2 days ago', '20 hours ago' to days elapsed."""
    if not text:
        return None
    text = text.lower().strip()

    # Fast path: regex for common patterns
    m = re.match(r"(\d+)\s*(day|hour|minute|week|month)s?\s*ago", text)
    if m:
        value = int(m.group(1))
        unit = m.group(2)
        if unit in ("hour", "minute"):
            return 0
        if unit == "day":
            return value
        if unit == "week":
            return value * 7
        if unit == "month":
            return value * 30
        return None

    # Common keywords
    if text in ("yesterday",):
        return 1
    if text in ("just now", "today", "just posted"):
        return 0

    # Fallback: dateparser (handles "a week ago", "last month", etc.)
    try:
        import dateparser
        dt = dateparser.parse(text)
        if dt:
            delta = datetime.now(timezone.utc) - dt.replace(tzinfo=timezone.utc)
            return max(0, delta.days)
    except ImportError:
        pass

    return None


def tier1_check(job, ttl_days):
    """Tier 1: field-based filtering using standardized output fields."""
    posted = job.get("posted_date", "")
    if not posted:
        return None

    # Try ISO format first (e.g. "2026-08-17T11:04:33.6830")
    age = days_since(posted)

    # Try relative time (SerpApi/JSearch: "2 days ago", "20 hours ago")
    if age is None:
        age = parse_relative_days(posted)

    if age is not None and age > ttl_days:
        return "expired", "Tier 1", f"posted {age} days ago, exceeds {ttl_days}-day threshold"

    return None


def extract_linkedin_job_id(url):
    """Extract LinkedIn job ID from various URL formats."""
    if "linkedin.com/jobs/view" not in url:
        return None
    path = urlparse(url).path.rstrip("/")
    match = re.search(r"(\d{8,})$", path)
    return match.group(1) if match else None


def resolve_check_url(url):
    """Resolve the actual URL to check. LinkedIn uses guest endpoint."""
    linkedin_id = extract_linkedin_job_id(url)
    if linkedin_id:
        return f"https://www.linkedin.com/jobs-guest/jobs/api/jobPosting/{linkedin_id}"
    return url


def is_http_403(tier, reason):
    """True when network_check hit an explicit HTTP 403."""
    return tier == "HTTP" and reason == "HTTP 403"


def collect_apply_urls(job):
    """Primary apply_url first, then deduplicated apply_alternates."""
    candidates = []
    seen = set()

    primary = (job.get("apply_url") or "").strip()
    if primary:
        candidates.append({"url": primary, "title": job.get("publisher", ""), "is_primary": True})
        seen.add(primary)

    for alt in job.get("apply_alternates") or []:
        link = (alt.get("link") or "").strip()
        if link and link not in seen:
            candidates.append({
                "url": link,
                "title": alt.get("title", ""),
                "is_primary": False,
            })
            seen.add(link)

    return candidates


def promote_alternate_to_primary(job, entry):
    """Swap a working alternate into apply_url; demote the old primary."""
    old_primary = job.get("apply_url", "")
    new_primary = entry["url"]
    job["apply_url"] = new_primary

    alts = []
    for alt in job.get("apply_alternates") or []:
        if alt.get("link") != new_primary:
            alts.append(alt)
    if old_primary and old_primary != new_primary:
        alts.insert(0, {"title": job.get("publisher", "original"), "link": old_primary})
    job["apply_alternates"] = alts


def network_check(url):
    """Tier 2: HTTP GET + content analysis."""
    check_url = resolve_check_url(url)

    try:
        resp = requests.get(check_url, timeout=TIMEOUT, headers=BROWSER_HEADERS, allow_redirects=True)

        if resp.status_code in (404, 410):
            return "expired", "HTTP", f"HTTP {resp.status_code}"

        # Redirect to generic page
        if resp.url != check_url:
            final_path = urlparse(resp.url).path
            for pattern in GENERIC_PATH_PATTERNS:
                if re.match(pattern, final_path):
                    return "expired", "Redirect", f"redirected to generic page {resp.url}"

        if resp.status_code == 403:
            return "unknown", "HTTP", "HTTP 403"

        if resp.status_code != 200:
            return "unknown", "HTTP", f"HTTP {resp.status_code}"

        html = resp.text

        # Too short → likely JS-only SPA
        if len(html) < 500:
            return "unknown", "Content", "page too short, likely JS-rendered"

        # Check: blocked page (bot challenge / captcha / auth-wall interstitial)
        html_lower = html.lower()
        if any(s in html_lower for s in BLOCKED_PAGE_SIGNALS):
            has_jobposting = '"jobposting"' in html_lower.replace(" ", "")
            if not has_jobposting:
                return "unknown", "Blocked", "bot challenge or auth-wall detected"

        # Check: JSON-LD structured data
        jsonld_matches = re.findall(
            r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
            html, re.DOTALL | re.IGNORECASE,
        )
        for match in jsonld_matches:
            try:
                ld = json.loads(match)
                items = ld if isinstance(ld, list) else [ld]
                for item in items:
                    if "JobPosting" in str(item.get("@type", "")):
                        valid_through = item.get("validThrough")
                        if valid_through:
                            dt = parse_date(valid_through)
                            if dt and dt < datetime.now(timezone.utc):
                                return "expired", "JSON-LD", f"validThrough {valid_through} has passed"
                            elif dt:
                                return "active", "JSON-LD", f"validThrough {valid_through} not passed"
            except (json.JSONDecodeError, TypeError):
                continue

        # Check: expired keywords
        for keyword in ALL_EXPIRED_KEYWORDS:
            if keyword.lower() in html_lower:
                return "expired", "Keyword", f'matched "{keyword}"'

        return "active", "Content", "page normal, no expiry signals"

    except requests.exceptions.Timeout:
        return "unknown", "HTTP", "request timed out"
    except requests.exceptions.RequestException as e:
        return "unknown", "HTTP", f"network error: {str(e)[:80]}"


def validate_job_apply_links(job, ttl_days):
    """Validate apply links; on HTTP 403 fall back to alternates.

    - First non-403 link that is active/unknown wins (alternate promoted to apply_url).
    - If every checked link returns HTTP 403, mark expired and exclude the job.
    - Other failures (404, expired keywords) on one link try the next candidate.
    """
    url = job.get("apply_url", "")
    if not url or not url.startswith("http"):
        return "expired", "N/A", "no valid URL"

    if is_generic_url(url):
        return "expired", "URL check", f"generic page, not a specific job posting: {url}"

    result = tier1_check(job, ttl_days)
    if result:
        return result

    candidates = collect_apply_urls(job)
    checked = 0
    forbidden_count = 0
    primary_was_403 = False

    for entry in candidates:
        candidate_url = entry["url"]
        if not candidate_url.startswith("http") or is_generic_url(candidate_url):
            continue

        checked += 1
        status, tier, reason = network_check(candidate_url)

        if is_http_403(tier, reason):
            forbidden_count += 1
            if entry["is_primary"]:
                primary_was_403 = True
            continue

        if status in ("active", "unknown"):
            if not entry["is_primary"]:
                promote_alternate_to_primary(job, entry)
                label = entry.get("title") or candidate_url
                tier = f"{tier}+fallback"
                reason = f"primary returned HTTP 403; using alternate ({label}): {reason}"
            return status, tier, reason

    if checked > 0 and forbidden_count == checked:
        return "expired", "HTTP 403", "all apply links returned HTTP 403"

    if primary_was_403 and forbidden_count > 0:
        return "expired", "HTTP", "primary and alternates unavailable (403 or expired)"

    return "expired", "HTTP", "all apply links expired or unavailable"


def validate_single(job, ttl_days):
    """Run two-tier validation on a single job. Returns (status, tier, reason)."""
    return validate_job_apply_links(job, ttl_days)


def validate_batch(jobs, ttl_days, max_workers=MAX_WORKERS):
    """Validate a batch of jobs in parallel."""
    results = [None] * len(jobs)

    # Pre-checks (no network)
    tier1_pass = []
    for i, job in enumerate(jobs):
        url = job.get("apply_url", "")
        if not url or not url.startswith("http"):
            results[i] = ("expired", "N/A", "no valid URL")
            continue
        if is_generic_url(url):
            results[i] = ("expired", "URL check", f"generic page: {url}")
            continue
        result = tier1_check(job, ttl_days)
        if result:
            results[i] = result
        else:
            tier1_pass.append(i)

    # Tier 2: network check in parallel (403 → alternate fallback per job)
    def check_job(idx):
        return idx, validate_job_apply_links(jobs[idx], ttl_days)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(check_job, i): i for i in tier1_pass}
        for future in as_completed(futures):
            idx, result = future.result()
            results[idx] = result

    return results


def main():
    parser = argparse.ArgumentParser(description="Validate job posting freshness")
    parser.add_argument("--url", help="Single URL to validate")
    parser.add_argument("--input", help="Input JSON file (search results)")
    parser.add_argument("--output", help="Output JSON file with validation results")
    parser.add_argument("--ttl", type=int, default=DEFAULT_TTL_DAYS, help=f"Max posting age in days (default: {DEFAULT_TTL_DAYS})")
    args = parser.parse_args()

    if not args.url and not args.input:
        parser.print_help()
        sys.exit(1)

    # Single URL mode
    if args.url:
        job = {"apply_url": args.url}
        status, tier, reason = validate_single(job, args.ttl)
        print(json.dumps({"url": args.url, "status": status, "tier": tier, "reason": reason}, ensure_ascii=False, indent=2))
        sys.exit(0 if status == "active" else 1 if status == "expired" else 2)

    # Batch mode
    with open(args.input) as f:
        data = json.load(f)

    jobs = data.get("jobs", data.get("data", {}).get("jobs", []))
    if not jobs:
        print("ERROR: No jobs found in input file", file=sys.stderr)
        sys.exit(1)

    print(f"Validating {len(jobs)} jobs (TTL={args.ttl} days)...", file=sys.stderr)
    start = time.time()

    results = validate_batch(jobs, args.ttl)

    elapsed = time.time() - start
    stats = {"active": 0, "expired": 0, "unknown": 0}

    for i, (status, tier, reason) in enumerate(results):
        jobs[i]["validation_status"] = status
        jobs[i]["validation_tier"] = tier
        jobs[i]["validation_reason"] = reason
        stats[status] += 1

    # Filter output
    output = {
        "metadata": {
            "total": len(jobs),
            "active": stats["active"],
            "expired": stats["expired"],
            "unknown": stats["unknown"],
            "elapsed_seconds": round(elapsed, 1),
            "ttl_days": args.ttl,
        },
        "jobs": [j for j in jobs if j["validation_status"] != "expired"],
        "expired_jobs": [j for j in jobs if j["validation_status"] == "expired"],
    }

    print(f"Done in {elapsed:.1f}s — active: {stats['active']}, expired: {stats['expired']}, unknown: {stats['unknown']}", file=sys.stderr)

    if args.output:
        with open(args.output, "w") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)
        print(f"Results saved to {args.output}", file=sys.stderr)
    else:
        print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
