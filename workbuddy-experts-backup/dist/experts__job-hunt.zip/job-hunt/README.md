# Job Hunt

A career coach that runs the full job-search workflow — from finding roles to tailoring resumes — and delivers a structured application checklist.

## Type

Agent (single AI expert)

## What It Does

- **Multi-platform job search**: aggregates SerpApi, JSearch, and USAJOBS with automatic dedup
- **Posting validity check**: verifies each posting link is still active and filters out dead listings
- **Eligibility & match evaluation**: filters hard JD mismatches and scores eligible jobs against the candidate profile
- **Resume tailoring**: reorganizes the resume around each target JD, staying ATS-friendly, and outputs a submission-ready file (docx/pdf)
- **Structured application checklist**: produces a complete report with job details, tailored resume paths, and match analysis

## Example Prompts

- "Help me find AI Engineer jobs in New York"
- "Tailor my resume for this job description"
- "Check whether this job posting link is still active"

## Avatar

The avatar is auto-generated under `avatars/`. To replace it with a custom one:
- Format: PNG (recommended) or JPG
- Size: 512×512 px
- File size: under 500KB

## Installation

Place the expert package directory under the experts directory:

```
$HOME/.workbuddy/plugins/marketplaces/my-experts/plugins/job-hunt/
```

Then run the registration command to make it visible:

```bash
python3 scripts/register_expert.py <expert-dir>
```

## Packaging & Sharing

```bash
./pack.sh              # → ~/Desktop/job-hunt-<commit>.zip
./pack.sh /tmp         # → /tmp/job-hunt-<commit>.zip
```
