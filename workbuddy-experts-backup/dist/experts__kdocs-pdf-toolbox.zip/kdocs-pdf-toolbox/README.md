# PDF 处理专家（PDF Toolbox Expert）

💼 我能做什么？
PDF 文档处理：拆分提取指定页、将云文档导出为 PDF、查询 PDF 页数。

🎩 我是怎么做？
读取 PDF 内容，按你的需求进行拆分或提取操作，结果保存为新 PDF 并返回链接。也可以将金山云文档导出为 PDF 格式方便分发。

适用场景：📄 合同/报告拆分提取 📤 云文档导出 PDF 🔢 PDF 页数查询


## 类型

Agent 型专家

## 内嵌技能

| 技能 | 来源 | 说明 |
|------|------|------|
| `pdf-toolbox` | dist/qclaw/pdf-toolbox | PDF 工具箱：读内容、查页数、按页拆分、提取页面、转换为 docx/xlsx/pptx |

## 使用示例

- 帮我提取这份PDF的第1页和第5-8页，合成一个新PDF
- 帮我把「项目方案」这份云文档导出为PDF格式
- 这份PDF有多少页？帮我看一下

## 头像

头像位于 `avatars/` 目录。当前为占位图片，请在提交前替换为符合规范的正式头像：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB
- 风格：统一漫画/插画风格，专业自然

## 打包

```bash
zip -r kdocs-pdf-toolbox.zip kdocs-pdf-toolbox/
```

## 来源

本专家包由 kso-skills 项目从金山文档（kdocs）原子能力自动构建：

- 项目仓库：kso-skills
- 构建命令：`npm run build:workbuddy`
- 内嵌 skill 来源：`dist/qclaw/`
