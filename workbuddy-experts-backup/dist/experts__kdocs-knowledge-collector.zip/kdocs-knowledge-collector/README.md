# 知识收藏专家（Knowledge Collector）

💼 我能做什么？
将零散消息、笔记、灵感整理为结构化文档，按主题分类并去重；
发送网页链接自动抓取文章全文保存为金山智能文档，永久收藏不怕链接失效；
读取云文档或上传文件，自动总结核心要点，或按指定风格生成新内容。

🎩 我是怎么做？
收集你发送的所有碎片信息，AI 按主题智能分类和组织，生成标题清晰、结构规范的文档。

适用场景：📝 零散笔记/灵感自动整理成文 🌐 微信文章/网页一键收藏 📄 文档摘要/要点提取


## 类型

Agent 型专家

## 内嵌技能

| 技能 | 来源 | 说明 |
|------|------|------|
| `web-clipper` | dist/qclaw/web-clipper | 网页剪藏：抓取网页内容并保存为云端文档 |
| `fragment-organize` | dist/qclaw/fragment-organize | 碎片整理：搜索 + 阅读 + 汇总成结构化文档 |
| `doc-writer` | dist/qclaw/doc-writer | 文档撰写与总结：多文档摘要、定期阅读播报 |

## 使用示例

- 帮我整理一下这些碎片笔记：
- AI大模型趋势
- 下周要交季报
- 新功能上线计划
- 竞品分析要做
- Agent是未来方向
- 帮我保存这篇公众号文章到金山文档 https://mp.weixin.qq.com/s/example123
- 帮我把「Q1总结」和「Q2计划」这两份文档汇总，生成一份半年度工作报告

## 头像

头像位于 `avatars/` 目录。当前为占位图片，请在提交前替换为符合规范的正式头像：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB
- 风格：统一漫画/插画风格，专业自然

## 打包

```bash
zip -r kdocs-knowledge-collector.zip kdocs-knowledge-collector/
```

## 来源

本专家包由 kso-skills 项目从金山文档（kdocs）原子能力自动构建：

- 项目仓库：kso-skills
- 构建命令：`npm run build:workbuddy`
- 内嵌 skill 来源：`dist/qclaw/`
