---
name: doc-writer
description: "搜索多份云文档，提取信息并自动生成总结报告或新文档内容。 当用户要求"汇总报告"、"多文档总结"、"定期播报"、"内容整合"时使用。 若只需读取单篇文档，请使用 doc-to-markdown 技能。
"
homepage: 
version: 1.0.0
metadata: {"openclaw":{"category":"kdocs","emoji":"✍"}}
---

# 文档总结与内容生成

文档总结与内容生成技能支持多文档信息提取和智能写作。

> 本技能依赖 `kdocs` 技能的基础文档操作能力（认证、文件管理等），请确保已安装该技能。详见 `references/core/` 目录。

---

## 能力范围

### 工具总览

| 类别 | 工具名 | 功能 |
|------|--------|------|
| **写文档** | `create_file` | 在云盘下新建文件或文件夹 |
| **写智能文档** | `otl.insert_content` | 向智能文档插入 Markdown/文本内容 |
| **写文档** | `scrape_url` | 网页剪藏，抓取网页内容并自动保存为智能文档 |
| **写智能文档** | `otl.block_insert` | 向智能文档插入一个或多个块 |
| **写文档** | `scrape_progress` | 查询网页剪藏任务进度 |
| **写智能文档** | `otl.block_delete` | 删除智能文档中一个或多个块区间 |
| **写文档** | `upload_file` | 全量上传写入文件（更新已有 docx/pdf 或新建并上传本地文件） |
| **查智能文档** | `otl.block_query` | 查询智能文档指定块的结构与内容 |
| **写文档** | `upload_attachment` | 向已有文档上传附件，支持 URL 或 Base64 |
| **读文档** | `list_files` | 获取指定文件夹下的子文件列表 |
| **用智能文档** | `otl.convert` | 将 HTML/Markdown 转换为智能文档块结构 |
| **读文档** | `download_file` | 获取文件下载信息 |
| **写智能文档** | `otl.block_update` | 更新智能文档指定块的内容或属性 |
| **管文档** | `move_file` | 批量移动文件(夹) |
| **管文档** | `rename_file` | 重命名文件（夹） |
| **管文档** | `share_file` | 开启文件分享 |
| **管文档** | `set_share_permission` | 修改分享链接属性 |
| **管文档** | `cancel_share` | 取消文件分享 |
| **管文档** | `get_share_info` | 获取分享链接信息 |
| **管文档** | `get_file_info` | 获取文件（夹）详细信息 |
| **用文档** | `read_file_content` | 文档内容抽取为 Markdown/纯文本 |
| **用文档** | `search_files` | 文件（夹）搜索 |
| **用文档** | `get_file_link` | 获取文件的云文档在线访问链接 |
| **管文档** | `list_labels` | 分页获取云盘自定义标签列表（可按归属者、标签类型筛选） |
| **管文档** | `create_label` | 创建自定义标签 |
| **管文档** | `get_label_meta` | 获取单个标签详情（含系统标签固定 ID） |
| **管文档** | `get_label_objects` | 获取某标签下的对象列表（文件/云盘等） |
| **管文档** | `batch_add_label_objects` | 批量为多个文档对象添加同一标签（打标签） |
| **管文档** | `batch_remove_label_objects` | 批量取消标签 |
| **管文档** | `batch_update_label_objects` | 批量更新标签下对象排序或属性 |
| **管文档** | `batch_update_labels` | 批量修改自定义标签名称或属性 |
| **管文档** | `list_star_items` | 获取收藏（星标）列表 |
| **管文档** | `batch_create_star_items` | 批量添加收藏 |
| **管文档** | `batch_delete_star_items` | 批量移除收藏 |
| **管文档** | `list_latest_items` | 获取最近访问文档列表 |
| **管文档** | `copy_file` | 复制文件到指定目录（可跨盘） |
| **管文档** | `check_file_name` | 检查目录下文件名是否已存在 |
| **管文档** | `list_deleted_files` | 获取回收站文件列表 |
| **管文档** | `restore_deleted_file` | 将回收站文件还原到原位置 |

### 详细参考

| 文档类型 | 参考文件 | 说明 |
|----------|----------|------|
| 智能文档（otl） | `references/otl_references.md` | 页面、文本、标题、待办等元素操作 |

---

## 核心操作摘要

### 搜索-读取-汇报撰写

`search_files` → `read_file_content`（多次）→ AI 分析 → `create_file` → `upload_file` → `get_file_link`


> 场景：搜索多份文档、提取信息、汇总撰写新报告

### 定期读取与播报

`search_files` → `read_file_content` → AI 摘要 → `get_file_link`


> 场景：定期读取指定文档，提取关键信息生成摘要

---

## 操作指南

### 获取文件标识指南

大多数工具需要 `file_id` 和 `drive_id` 参数。按用户提供的信息选择定位方式：

| 用户提供 | 定位方式 |
|---------|---------|
| 文件名/关键词 | `search_files` → 返回结果中包含 `file_id` 和 `drive_id` |
| 文档链接 | 从 URL 提取 `link_id`（见下方链接解析）→ `get_share_info(link_id)` → 取 `file_id` 和 `drive_id` |
| 已知 `file_id` | `get_file_info(file_id)` → 补充获取 `drive_id` |
| 创建文件（指定目录） | `search_files` 搜索目标目录 → 取 `drive_id` 和 `file_id`（作为 `parent_id`） |
| 创建文件（未指定目录） | `list_files(parent_id="0", page_size=1)` → 从任意返回文件取 `drive_id`，然后 `create_file(drive_id=xxx, parent_id="0", ...)` |

> 根目录的 `parent_id` 固定为 `"0"`。

#### 文档链接解析

当链接域名为 `365.kdocs.cn` 或 `www.kdocs.cn` 时，按路径格式提取末尾的 `link_id`：

| 路径格式 | 提取规则 |
|---------|---------|
| `/l/<link_id>` | 文件分享链接 |
| `/folder/<link_id>` | 文件夹分享链接 |
| `/view/l/<link_id>` | 文件预览链接 |

提取后调用 `get_share_info(link_id)` 获取 `file_id` 和 `drive_id`。

> **AIPPT 文档转 PPT 快捷方式**：当用户提供金山文档链接并要求生成 PPT 时，从 URL 提取的 `link_id` 可直接以 `type: "v7_file_id"` 传入 `aippt.doc_outline_options` 和 `aippt.doc_outline`，无需先调用 `get_share_info` 获取 `file_id`。

### 文件读取指南

不同文件类型使用不同的读取工具，选错工具会导致读不到内容或拿到非结构化数据。

#### 读取流程

**智能文档**（.otl）——优先用 `otl.block_query`：

`otl.block_query`（`blockIds: ["doc"]`）可完整获取文档的块结构与内容。`read_file_content` 对 otl 存在内容遗漏风险，仅在需要导出 Markdown 时使用。

**文字文档 / PDF**（.docx / .pdf）——用 `read_file_content`：

返回内容已自动转为 Markdown，可直接用于 AI 分析（摘要、审查、问答等）。

**表格类**（.xlsx / .ksheet）——**勿用 `read_file_content`**：

1. `sheet.get_sheets_info` 获取工作表列表和结构
2. `sheet.get_range_data` 按范围读取单元格数据
3. 若需筛选/分页/去重，改用 `sheet.retrieve_record`

**多维表格**（.dbt）——**勿用 `read_file_content`**：

1. `dbsheet.get_schema` 获取数据表、字段、视图结构
2. `dbsheet.list_records` / `dbsheet.get_record` 读取记录

**CSV 文件**（.csv）——**不支持，勿用 `read_file_content`**：

暂不支持 CSV 在线读取。建议用户将 CSV 转为 .xlsx 后用 `sheet.*` 工具读取。

#### 注意事项

- **PDF 精度**：复杂排版（表格、图片、多栏）可能存在精度损失，提取结果为近似纯文本
- **空读取排查**：若 `read_file_content` 返回空内容，检查：(1) 文件是否为空文件 (2) 文件格式是否受支持 (3) 文件后缀与实际格式是否匹配

### 文件创建与写入指南

> 已有文件（用户提供了 `file_id` 或通过搜索/链接定位到文件）→ 跳过「类型选择」和 `create_file`，直接看各类型的「更新」路径。

#### 类型选择决策树

仅在需要新建文件时使用：

```
用户需要创建文档
├── 需要丰富排版/图文混排？ → otl（智能文档）首选
├── 需要表格/数据处理？
│   ├── 简单表格数据 → xlsx
│   ├── 需要多视图/字段管理/看板（智能表格产品形态）→ ksheet（智能表格）
│   └── 需要多数据表、关联、丰富字段类型与甘特/画册等多视图（多维表格产品形态）→ dbt（多维表格）
├── 需要生成 PDF？ → pdf
├── 需要兼容 Word？ → docx
├── 需要生成 PPT？ → pptx
└── 不确定 → otl（智能文档）默认推荐
```

#### 写入流程

**智能文档**（.otl）——**勿用 `upload_file`**：

- 新建：`create_file` → `otl.insert_content` 写入内容
- 更新：`otl.insert_content` 插入内容（`pos=begin` 从开头插入，`pos=end` 在末尾追加）

**文字文档**（.docx）：

- 新建：`create_file` → `upload_file(file_id, content_base64)` 写入内容
- 更新：`upload_file(file_id, content_base64)` 全量覆盖
- Markdown 源内容须传 `content_format="markdown"`

**PDF**（.pdf）——新建无需 `create_file`：

- 新建：`upload_file(drive_id, parent_id, name="xxx.pdf", content_base64=...)`
- 更新：`upload_file(file_id, content_base64=...)` 全量覆盖

**表格**（.xlsx / .ksheet）：

- 新建：`create_file` → `sheet.update_range_data` 批量写入
- 更新：`sheet.update_range_data` 按范围写入

**多维表格**（.dbt）：

- 新建：`create_file` → `dbsheet.create_sheet` → `dbsheet.create_fields` → `dbsheet.create_records`
- 更新：`dbsheet.update_records` / `dbsheet.create_records` 增改记录

**演示文稿**（.pptx）：

- 新建：`create_file` 或 `upload_file` 上传本地 pptx
- 主题生成型 AI PPT：优先走 `aippt.theme_questions` → `aippt.theme_deep_research` → `aippt.theme_outline` → 本地格式转换 → `aippt.theme_generate_html_pptx` → `upload_file`


---

## 风险控制

以下工具涉及数据变更，调用前必须遵守对应的风险控制要求。

### 高风险（不可逆操作）

| 工具 | 约束 |
|------|------|
| `otl.block_delete` | **用户确认**：删除操作不可逆，执行前必须向用户确认删除范围；**前置检查**：先 otl.block_query 确认待删除块的内容，避免误删 |
| `cancel_share` | **用户确认**（mode=delete）：永久删除分享链接，不可恢复，必须向用户确认；**禁止**（mode=delete）：禁止自动重试，失败后报告用户；**提示**：建议优先使用 mode=pause（可恢复）；**后置验证**：get_share_info 确认分享状态已变更 |

### 中风险（影响较大操作）

| 工具 | 约束 |
|------|------|
| `create_file` | **前置检查**：search_files 查重，避免创建同名文件；**后置验证**：get_file_info 确认文件已创建；**提示**：文件名必须带后缀，否则创建失败；**提示**：PDF 不支持 create_file，需使用 upload_file |
| `otl.insert_content` | **前置检查**：先 otl.block_query 读取现有内容，了解文档当前状态；**提示**：仅支持插入操作（begin/end），不支持替换已有内容 |
| `otl.block_insert` | **前置检查**：先 otl.block_query 了解文档块结构，确认插入位置；**提示**：返回结果因内容和文档状态不同而异，以 code == 0 判断成功 |
| `upload_file` | **前置检查**（更新已有文件时）：先 read_file_content 读取现有内容，确认覆盖范围；**后置验证**：read_file_content 确认写入结果；**提示**：更新模式支持 docx/pdf；新建模式支持 doc/docx/xls/xlsx/ppt/pptx/pdf；**提示**：Markdown 源内容务必传 content_format=markdown |
| `otl.block_update` | **前置检查**：先 otl.block_query 了解目标块结构，确认更新内容；**提示**：update_attrs 是覆盖操作，不需更新的属性需保持原样传入 |
| `move_file` | **用户确认**（批量操作（多个 file_ids））：批量移动需向用户确认文件列表和目标位置；**前置检查**：确认目标文件夹存在（get_file_info）；**后置验证**：get_file_info 确认 parent_id 为目标文件夹；**提示**：移动为异步任务，返回 `task_id` |
| `share_file` | **禁止**：未经用户明确要求，禁止调用此工具；**后置验证**：确认返回的分享链接有效 |
| `set_share_permission` | **禁止**：未经用户明确要求，禁止修改分享权限 |

---

## 工具组合速查

| 用户需求 | 推荐工具组合 |
|----------|-------------|
| 搜索多份文档、提取信息、汇总撰写新报告 | `search_files` → `read_file_content`（多次）→ AI 分析 → `create_file` → `upload_file` → `get_file_link` |
| 定期读取指定文档，提取关键信息生成摘要 | `search_files` → `read_file_content` → AI 摘要 → `get_file_link` |
