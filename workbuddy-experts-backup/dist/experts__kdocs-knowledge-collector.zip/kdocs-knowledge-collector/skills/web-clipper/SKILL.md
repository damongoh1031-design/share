---
name: web-clipper
description: "将网页内容剪藏并自动保存为金山文档智能文档（.otl）。 当用户提供 URL 并要求"保存网页"、"收藏网页"、"剪藏"、"网页存到文档"时使用。 若需要存入知识库，请使用 knowledge-save 技能。
"
homepage: 
version: 1.0.0
metadata: {"openclaw":{"category":"kdocs","emoji":"🌐"}}
---

# 网页收藏

网页收藏技能可以将任意网页内容保存为金山文档。

> 本技能依赖 `kdocs` 技能的基础文档操作能力（认证、文件管理等），请确保已安装该技能。详见 `references/core/` 目录。

---

## 能力范围

### 工具总览

| 类别 | 工具名 | 功能 |
|------|--------|------|
| **写文档** | `create_file` | 在云盘下新建文件或文件夹 |
| **写文档** | `scrape_url` | 网页剪藏，抓取网页内容并自动保存为智能文档 |
| **写文档** | `scrape_progress` | 查询网页剪藏任务进度 |
| **写文档** | `upload_file` | 全量上传写入文件（更新已有 docx/pdf 或新建并上传本地文件） |
| **写文档** | `upload_attachment` | 向已有文档上传附件，支持 URL 或 Base64 |
| **读文档** | `list_files` | 获取指定文件夹下的子文件列表 |
| **读文档** | `download_file` | 获取文件下载信息 |
| **管文档** | `move_file` | 批量移动文件(夹) |
| **管文档** | `rename_file` | 重命名文件（夹） |
| **管文档** | `share_file` | 开启文件分享 |
| **管文档** | `set_share_permission` | 修改分享链接属性 |
| **管文档** | `cancel_share` | 取消文件分享 |
| **管文档** | `get_share_info` | 获取分享链接信息 |
| **管文档** | `get_file_info` | 获取文件（夹）详细信息 |
| **用文档** | `read_file_content` | 文档内容抽取为 Markdown/纯文本 |
| **用文档** | `search_files` | 文件（夹）搜索 |
| **用文档** | `get_file_link` | 获取文件的云文档在线访问链接 |
| **管文档** | `list_labels` | 分页获取云盘自定义标签列表（可按归属者、标签类型筛选） |
| **管文档** | `create_label` | 创建自定义标签 |
| **管文档** | `get_label_meta` | 获取单个标签详情（含系统标签固定 ID） |
| **管文档** | `get_label_objects` | 获取某标签下的对象列表（文件/云盘等） |
| **管文档** | `batch_add_label_objects` | 批量为多个文档对象添加同一标签（打标签） |
| **管文档** | `batch_remove_label_objects` | 批量取消标签 |
| **管文档** | `batch_update_label_objects` | 批量更新标签下对象排序或属性 |
| **管文档** | `batch_update_labels` | 批量修改自定义标签名称或属性 |
| **管文档** | `list_star_items` | 获取收藏（星标）列表 |
| **管文档** | `batch_create_star_items` | 批量添加收藏 |
| **管文档** | `batch_delete_star_items` | 批量移除收藏 |
| **管文档** | `list_latest_items` | 获取最近访问文档列表 |
| **管文档** | `copy_file` | 复制文件到指定目录（可跨盘） |
| **管文档** | `check_file_name` | 检查目录下文件名是否已存在 |
| **管文档** | `list_deleted_files` | 获取回收站文件列表 |
| **管文档** | `restore_deleted_file` | 将回收站文件还原到原位置 |


---

## 核心操作摘要

### 网页剪藏

> 🎯 **当用户要求保存网页/URL 到金山文档时，直接调用 `scrape_url`。禁止先用 `web_fetch`、`web_search` 或浏览器抓取内容。**

**触发识别**：用户消息中同时包含 **URL**（非金山文档链接）+ **保存/存到/收藏/剪藏** 等意图词时，走此流程。

```
步骤 1: scrape_url(url="https://example.com")
        → 返回 job_id

步骤 2: scrape_progress(job_id=xxx)
        → 轮询（每 2-5 秒），status 判定：
          1  = 完成 → 获得 scrape_file_id（剪藏专用标识）
          -1 = 失败 → 检查 URL 或重试
          其他 = 进行中 → 继续轮询

步骤 3: get_file_link(file_id=scrape_file_id)
        → 返回文档在线链接
```

---

## 操作指南

### 获取文件标识指南

大多数工具需要 `file_id` 和 `drive_id` 参数。按用户提供的信息选择定位方式：

| 用户提供 | 定位方式 |
|---------|---------|
| 文件名/关键词 | `search_files` → 返回结果中包含 `file_id` 和 `drive_id` |
| 文档链接 | 从 URL 提取 `link_id`（见下方链接解析）→ `get_share_info(link_id)` → 取 `file_id` 和 `drive_id` |
| 已知 `file_id` | `get_file_info(file_id)` → 补充获取 `drive_id` |
| 创建文件（指定目录） | `search_files` 搜索目标目录 → 取 `drive_id` 和 `file_id`（作为 `parent_id`） |
| 创建文件（未指定目录） | `list_files(parent_id="0", page_size=1)` → 从任意返回文件取 `drive_id`，然后 `create_file(drive_id=xxx, parent_id="0", ...)` |

> 根目录的 `parent_id` 固定为 `"0"`。

#### 文档链接解析

当链接域名为 `365.kdocs.cn` 或 `www.kdocs.cn` 时，按路径格式提取末尾的 `link_id`：

| 路径格式 | 提取规则 |
|---------|---------|
| `/l/<link_id>` | 文件分享链接 |
| `/folder/<link_id>` | 文件夹分享链接 |
| `/view/l/<link_id>` | 文件预览链接 |

提取后调用 `get_share_info(link_id)` 获取 `file_id` 和 `drive_id`。

> **AIPPT 文档转 PPT 快捷方式**：当用户提供金山文档链接并要求生成 PPT 时，从 URL 提取的 `link_id` 可直接以 `type: "v7_file_id"` 传入 `aippt.doc_outline_options` 和 `aippt.doc_outline`，无需先调用 `get_share_info` 获取 `file_id`。


---

## 风险控制

以下工具涉及数据变更，调用前必须遵守对应的风险控制要求。

### 高风险（不可逆操作）

| 工具 | 约束 |
|------|------|
| `cancel_share` | **用户确认**（mode=delete）：永久删除分享链接，不可恢复，必须向用户确认；**禁止**（mode=delete）：禁止自动重试，失败后报告用户；**提示**：建议优先使用 mode=pause（可恢复）；**后置验证**：get_share_info 确认分享状态已变更 |

### 中风险（影响较大操作）

| 工具 | 约束 |
|------|------|
| `create_file` | **前置检查**：search_files 查重，避免创建同名文件；**后置验证**：get_file_info 确认文件已创建；**提示**：文件名必须带后缀，否则创建失败；**提示**：PDF 不支持 create_file，需使用 upload_file |
| `upload_file` | **前置检查**（更新已有文件时）：先 read_file_content 读取现有内容，确认覆盖范围；**后置验证**：read_file_content 确认写入结果；**提示**：更新模式支持 docx/pdf；新建模式支持 doc/docx/xls/xlsx/ppt/pptx/pdf；**提示**：Markdown 源内容务必传 content_format=markdown |
| `move_file` | **用户确认**（批量操作（多个 file_ids））：批量移动需向用户确认文件列表和目标位置；**前置检查**：确认目标文件夹存在（get_file_info）；**后置验证**：get_file_info 确认 parent_id 为目标文件夹；**提示**：移动为异步任务，返回 `task_id` |
| `share_file` | **禁止**：未经用户明确要求，禁止调用此工具；**后置验证**：确认返回的分享链接有效 |
| `set_share_permission` | **禁止**：未经用户明确要求，禁止修改分享权限 |

---

## 工具组合速查

| 用户需求 | 推荐工具组合 |
|----------|-------------|
| 将网页内容保存为金山文档 | `scrape_url` → `scrape_progress`（轮询至完成）→ `get_file_link` |
